package com.vento.launcher

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.*
import android.widget.*
import java.io.File

/** Iconos dibujados con codigo (no dependen de fuentes ni de imagenes). */
class IconView(ctx: Context, var kind: Int, var tint: Int = Color.WHITE) : View(ctx) {
    companion object {
        const val HOME = 0; const val APPS = 1; const val GEAR = 2; const val PREV = 3
        const val PLAY = 4; const val PAUSE = 5; const val NEXT = 6; const val PLUS = 7
    }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        c.save()
        c.translate((width - s) / 2, (height - s) / 2)
        c.scale(s / 24f, s / 24f)
        p.color = tint; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND; p.strokeWidth = 2f
        val path = Path()
        when (kind) {
            HOME -> {
                p.style = Paint.Style.STROKE
                path.moveTo(3f, 11f); path.lineTo(12f, 3f); path.lineTo(21f, 11f)
                path.moveTo(5.5f, 9.5f); path.lineTo(5.5f, 20f); path.lineTo(10f, 20f); path.lineTo(10f, 14f)
                path.lineTo(14f, 14f); path.lineTo(14f, 20f); path.lineTo(18.5f, 20f); path.lineTo(18.5f, 9.5f)
                c.drawPath(path, p)
            }
            APPS -> {
                p.style = Paint.Style.FILL
                for ((x, y) in listOf(4f to 4f, 14f to 4f, 4f to 14f, 14f to 14f)) c.drawRoundRect(x, y, x + 6f, y + 6f, 1.5f, 1.5f, p)
            }
            GEAR -> {
                p.style = Paint.Style.STROKE
                c.drawCircle(12f, 12f, 6f, p); c.drawCircle(12f, 12f, 2.2f, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    c.drawLine(12f + (6.8 * Math.cos(a)).toFloat(), 12f + (6.8 * Math.sin(a)).toFloat(),
                        12f + (9.6 * Math.cos(a)).toFloat(), 12f + (9.6 * Math.sin(a)).toFloat(), p)
                }
            }
            PREV -> {
                p.style = Paint.Style.FILL
                c.drawRect(5f, 5f, 7.5f, 19f, p)
                path.moveTo(19f, 5f); path.lineTo(9f, 12f); path.lineTo(19f, 19f); path.close(); c.drawPath(path, p)
            }
            NEXT -> {
                p.style = Paint.Style.FILL
                c.drawRect(16.5f, 5f, 19f, 19f, p)
                path.moveTo(5f, 5f); path.lineTo(15f, 12f); path.lineTo(5f, 19f); path.close(); c.drawPath(path, p)
            }
            PLAY -> {
                p.style = Paint.Style.FILL
                path.moveTo(8f, 5f); path.lineTo(19f, 12f); path.lineTo(8f, 19f); path.close(); c.drawPath(path, p)
            }
            PAUSE -> {
                p.style = Paint.Style.FILL
                c.drawRoundRect(6f, 5f, 10f, 19f, 1f, 1f, p); c.drawRoundRect(14f, 5f, 18f, 19f, 1f, 1f, p)
            }
            PLUS -> {
                p.style = Paint.Style.STROKE
                c.drawLine(12f, 5f, 12f, 19f, p); c.drawLine(5f, 12f, 19f, 12f, p)
            }
        }
        c.restore()
    }
}

class MainActivity : Activity() {
    private val accent = Color.parseColor("#4A9EFF")   // azul frio
    private val gray = Color.parseColor("#8A94A6")
    private lateinit var home: View
    private lateinit var drawer: View
    private lateinit var car: ImageView
    private lateinit var favHolder: FrameLayout
    private lateinit var tTitle: TextView
    private lateinit var tArtist: TextView
    private lateinit var art: ImageView
    private lateinit var playIcon: IconView
    private lateinit var navHome: FrameLayout
    private lateinit var navHomeIcon: IconView
    private lateinit var navApps: FrameLayout
    private lateinit var navAppsIcon: IconView
    private var ctrl: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() { updateMedia(); handler.postDelayed(this, 1500) }
    }
    private val prefs by lazy { getSharedPreferences("vento", MODE_PRIVATE) }
    private val apps by lazy { loadApps() }

    class AppItem(val label: String, val icon: Drawable, val pkg: String)

    // ---------- utilidades ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)

    private fun glass(r: Int = 24) = GradientDrawable().apply {
        setColor(Color.parseColor("#14FFFFFF")); cornerRadius = dp(r).toFloat()
        setStroke(dp(1), Color.parseColor("#1FFFFFFF"))
    }

    private fun oval(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }

    private fun tv(s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun clipRound(v: View, r: Int) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: Outline) {
                o.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat())
            }
        }
        v.clipToOutline = true
    }

    private fun circleBtn(icon: IconView, sizeDp: Int, color: Int, onClick: () -> Unit) = FrameLayout(this).apply {
        background = oval(color)
        addView(icon, FrameLayout.LayoutParams(dp(sizeDp / 2), dp(sizeDp / 2), Gravity.CENTER))
        setOnClickListener { onClick() }
    }

    // ---------- pantalla principal ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#070A12"), Color.parseColor("#0C1730"), Color.parseColor("#0A1226"))
            )
        }
        home = buildHome()
        drawer = buildDrawer()
        drawer.visibility = View.GONE
        val content = FrameLayout(this).apply { addView(home); addView(drawer) }
        root.addView(sidebar(), lp(dp(92), -1))
        root.addView(content, lp(0, -1, 1f))
        setContentView(root)
        show(true)
    }

    override fun onResume() { super.onResume(); handler.post(poll) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(poll) }
    override fun onBackPressed() { show(true) }
    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); show(true) }

    private fun show(homeVisible: Boolean) {
        home.visibility = if (homeVisible) View.VISIBLE else View.GONE
        drawer.visibility = if (homeVisible) View.GONE else View.VISIBLE
        styleNav(navHome, navHomeIcon, homeVisible)
        styleNav(navApps, navAppsIcon, !homeVisible)
    }

    private fun styleNav(btn: FrameLayout, icon: IconView, sel: Boolean) {
        btn.background = oval(if (sel) accent else Color.parseColor("#1AFFFFFF"))
        icon.tint = if (sel) Color.parseColor("#06101F") else Color.WHITE
        icon.invalidate()
    }

    private fun sidebar() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(0, dp(20), 0, dp(20))
        setBackgroundColor(Color.parseColor("#66000000"))
        navHomeIcon = IconView(this@MainActivity, IconView.HOME)
        navHome = circleBtn(navHomeIcon, 56, accent) { show(true) }
        navAppsIcon = IconView(this@MainActivity, IconView.APPS)
        navApps = circleBtn(navAppsIcon, 56, accent) { show(false) }
        val gear = circleBtn(IconView(this@MainActivity, IconView.GEAR), 56, Color.parseColor("#1AFFFFFF")) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
        for (v in listOf(navHome, navApps, gear)) addView(v, lp(dp(56), dp(56)).apply { bottomMargin = dp(16) })
        addView(View(this@MainActivity), lp(1, 0, 1f))
        addView(TextClock(this@MainActivity).apply {
            format12Hour = "h:mm"; format24Hour = "HH:mm"
            setTextColor(Color.WHITE); textSize = 17f; typeface = Typeface.DEFAULT_BOLD
        })
    }

    private fun buildHome(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(22), dp(22), dp(22), dp(22))
        }
        row.addView(carCard(), lp(0, -1, 3f).apply { rightMargin = dp(18) })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(playerCard(), lp(-1, 0, 1f).apply { bottomMargin = dp(12) })
        favHolder = FrameLayout(this)
        refreshFavs()
        col.addView(favHolder, lp(-1, 0, 1.5f))
        row.addView(col, lp(0, -1, 2f))
        return row
    }

    // ---------- tarjeta del auto ----------
    private fun carCard(): View {
        val f = FrameLayout(this).apply { background = glass(30) }

        val glow = View(this).apply {
            background = GradientDrawable().apply {
                gradientType = GradientDrawable.RADIAL_GRADIENT
                gradientRadius = dp(280).toFloat()
                setColors(intArrayOf(Color.parseColor("#704A9EFF"), Color.parseColor("#004A9EFF")))
            }
        }
        f.addView(glow, FrameLayout.LayoutParams(-1, dp(320), Gravity.BOTTOM).apply { bottomMargin = dp(10) })
        ObjectAnimator.ofFloat(glow, "alpha", 0.45f, 1f).apply {
            duration = 3200; repeatMode = android.animation.ValueAnimator.REVERSE
            repeatCount = android.animation.ValueAnimator.INFINITE; start()
        }

        car = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(18), dp(110), dp(18), dp(70))
        }
        val saved = File(filesDir, "car.png")
        val bmp = if (saved.exists()) decode(saved) else null
        if (bmp != null) car.setImageBitmap(bmp) else car.setImageResource(R.drawable.vento)
        f.addView(car)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextClock(this@MainActivity).apply {
                format12Hour = "h:mm"; format24Hour = "HH:mm"
                setTextColor(Color.WHITE); textSize = 46f
                typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            })
            addView(TextClock(this@MainActivity).apply {
                format12Hour = "EEEE d 'de' MMMM"; format24Hour = "EEEE d 'de' MMMM"
                setTextColor(gray); textSize = 16f
            })
        }
        f.addView(top, FrameLayout.LayoutParams(-2, -2).apply { setMargins(dp(28), dp(20), 0, 0) })

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv("VOLKSWAGEN", 12f, accent, true).apply { letterSpacing = 0.25f })
            addView(tv("Vento Starline", 24f, Color.WHITE, true))
            addView(tv("Mantén presionado para cambiar la foto", 11f, gray))
        }
        f.addView(bottom, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM).apply {
            setMargins(dp(28), 0, 0, dp(20))
        })
        f.setOnLongClickListener { pickPhoto(); true }
        return f
    }

    private fun pickPhoto() {
        try {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1)
        } catch (e: Exception) {
            Toast.makeText(this, "No hay galería o explorador de archivos", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r != 1 || c != RESULT_OK) return
        val uri = d?.data ?: return
        try {
            val f = File(filesDir, "car.png")
            contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            decode(f)?.let { car.setImageBitmap(it) }
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo cargar la imagen", Toast.LENGTH_LONG).show()
        }
    }

    private fun decode(f: File): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > 2000) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    // ---------- musica ----------
    private fun key(code: Int) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun playPause() {
        val c = ctrl
        if (c == null) { key(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); return }
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
        else c.transportControls.play()
    }

    private fun updateMedia() {
        try {
            val msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(this, MediaListener::class.java))
            ctrl = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
            val md = ctrl?.metadata
            if (md == null) {
                tTitle.text = "Nada reproduciéndose"; tArtist.text = "Abre Spotify o YouTube Music"
                art.setImageDrawable(null); playIcon.kind = IconView.PLAY; playIcon.invalidate()
                return
            }
            tTitle.text = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Sin título"
            tArtist.text = md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
            val bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            if (bmp != null) art.setImageBitmap(bmp) else art.setImageDrawable(null)
            playIcon.kind = if (ctrl?.playbackState?.state == PlaybackState.STATE_PLAYING) IconView.PAUSE else IconView.PLAY
            playIcon.invalidate()
        } catch (e: SecurityException) {
            ctrl = null
            tTitle.text = "Activar música en pantalla"; tArtist.text = "Toca aquí y permite el acceso"
        } catch (e: Exception) { }
    }

    private fun playerCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(26)
            setPadding(dp(16), dp(14), dp(16), dp(12))
            setOnClickListener {
                if (ctrl == null) try {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Ve a Ajustes > Acceso a notificaciones", Toast.LENGTH_LONG).show()
                }
            }
        }
        art = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { setColor(Color.parseColor("#1AFFFFFF")); cornerRadius = dp(14).toFloat() }
        }
        clipRound(art, 14)
        tTitle = tv("Nada reproduciéndose", 18f, Color.WHITE, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        tArtist = tv("Abre Spotify o YouTube Music", 14f, gray).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            addView(tTitle); addView(tArtist)
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(art, lp(dp(76), dp(76)).apply { rightMargin = dp(14) })
        head.addView(info, lp(0, -2, 1f))
        card.addView(head, lp(-1, 0, 1f))

        playIcon = IconView(this, IconView.PLAY, Color.parseColor("#06101F"))
        val soft = Color.parseColor("#1AFFFFFF")
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER }
        controls.addView(circleBtn(IconView(this, IconView.PREV), 56, soft) {
            ctrl?.transportControls?.skipToPrevious() ?: key(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        }, lp(dp(56), dp(56)).apply { setMargins(dp(10), 0, dp(10), 0) })
        controls.addView(circleBtn(playIcon, 64, accent) { playPause() },
            lp(dp(64), dp(64)).apply { setMargins(dp(10), 0, dp(10), 0) })
        controls.addView(circleBtn(IconView(this, IconView.NEXT), 56, soft) {
            ctrl?.transportControls?.skipToNext() ?: key(KeyEvent.KEYCODE_MEDIA_NEXT)
        }, lp(dp(56), dp(56)).apply { setMargins(dp(10), 0, dp(10), 0) })
        card.addView(controls, lp(-1, -2).apply { topMargin = dp(8) })
        return card
    }

    // ---------- favoritos editables ----------
    private fun defaultFavs(): List<String> {
        val known = listOf(
            "com.google.android.apps.maps", "com.waze", "com.spotify.music",
            "com.google.android.apps.youtube.music", "com.google.android.youtube", "com.android.chrome"
        )
        val f = known.filter { p -> apps.any { it.pkg == p } }.toMutableList()
        while (f.size < 6) f.add("")
        return f.take(6)
    }

    private fun favs(): MutableList<String> {
        val saved = prefs.getString("favs", null) ?: return defaultFavs().toMutableList()
        val l = saved.split(",").toMutableList()
        while (l.size < 6) l.add("")
        return l.take(6).toMutableList()
    }

    private fun saveFavs(l: List<String>) { prefs.edit().putString("favs", l.joinToString(",")).apply() }

    private fun refreshFavs() {
        favHolder.removeAllViews()
        val f = favs()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (r in 0 until 2) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until 3) {
                val i = r * 3 + c
                val a = apps.find { it.pkg == f[i] }
                val v = if (a != null) tile(a) { chooseApp(i) } else plusTile(i)
                row.addView(v, lp(0, -1, 1f).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) })
            }
            box.addView(row, lp(-1, 0, 1f))
        }
        favHolder.addView(box)
    }

    private fun chooseApp(i: Int) {
        val names = apps.map { it.label }.toTypedArray()
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Elegir app para este espacio")
            .setItems(names) { _, w -> val l = favs(); l[i] = apps[w].pkg; saveFavs(l); refreshFavs() }
            .setNeutralButton("Quitar") { _, _ -> val l = favs(); l[i] = ""; saveFavs(l); refreshFavs() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun plusTile(i: Int): View = LinearLayout(this).apply {
        gravity = Gravity.CENTER
        background = glass(20)
        addView(IconView(this@MainActivity, IconView.PLUS, gray), lp(dp(28), dp(28)))
        setOnClickListener { chooseApp(i) }
    }

    // ---------- apps ----------
    private fun tile(a: AppItem, onLong: (() -> Unit)? = null): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = glass(20)
        setPadding(dp(6), dp(8), dp(6), dp(8))
        addView(ImageView(this@MainActivity).apply { setImageDrawable(a.icon) }, lp(dp(52), dp(52)))
        addView(tv(a.label, 12f).apply {
            gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(4), 0, 0)
        })
        setOnClickListener { packageManager.getLaunchIntentForPackage(a.pkg)?.let { i -> startActivity(i) } }
        if (onLong != null) setOnLongClickListener { onLong(); true }
    }

    private fun grid(items: List<AppItem>, cols: Int, rowH: Int): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        items.chunked(cols).forEach { chunk ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in 0 until cols) {
                val v = if (i < chunk.size) tile(chunk[i]) else View(this)
                r.addView(v, lp(0, -1, 1f).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) })
            }
            box.addView(r, lp(-1, rowH))
        }
        return box
    }

    private fun buildDrawer(): View = ScrollView(this).apply {
        setPadding(dp(18), dp(18), dp(18), dp(18))
        addView(grid(apps, 6, dp(112)))
    }

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.loadIcon(pm), it.activityInfo.packageName) }
            .sortedBy { it.label.lowercase() }
    }
}
