package com.vento.launcher

import android.service.notification.NotificationListenerService

// Servicio vacio: solo sirve para que Android permita leer la musica que suena.
class MediaListener : NotificationListenerService()
