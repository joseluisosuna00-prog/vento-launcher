package com.vento.launcher

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.os.SystemClock
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.*
import android.widget.*
import java.io.File
import java.util.Locale
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.res.Configuration
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.speech.tts.TextToSpeech

/** Iconos dibujados con codigo (no dependen de fuentes ni de imagenes). */
class IconView(ctx: Context, var kind: Int, var tint: Int = Color.WHITE) : View(ctx) {
    companion object {
        const val HOME = 0; const val APPS = 1; const val GEAR = 2; const val PREV = 3
        const val PLAY = 4; const val PAUSE = 5; const val NEXT = 6; const val PLUS = 7; const val BT = 8; const val RADIO = 9; const val SUN = 10; const val CHEV = 11
    }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        c.save()
        c.translate((width - s) / 2, (height - s) / 2)
        c.scale(s / 24f, s / 24f)
        p.color = tint; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND; p.strokeWidth = 2f
        val path = Path()
        when (kind) {
            HOME -> {
                p.style = Paint.Style.STROKE
                path.moveTo(3f, 11f); path.lineTo(12f, 3f); path.lineTo(21f, 11f)
                path.moveTo(5.5f, 9.5f); path.lineTo(5.5f, 20f); path.lineTo(10f, 20f); path.lineTo(10f, 14f)
                path.lineTo(14f, 14f); path.lineTo(14f, 20f); path.lineTo(18.5f, 20f); path.lineTo(18.5f, 9.5f)
                c.drawPath(path, p)
            }
            APPS -> {
                p.style = Paint.Style.FILL
                for ((x, y) in listOf(4f to 4f, 14f to 4f, 4f to 14f, 14f to 14f)) c.drawRoundRect(x, y, x + 6f, y + 6f, 1.5f, 1.5f, p)
            }
            GEAR -> {
                p.style = Paint.Style.STROKE
                c.drawCircle(12f, 12f, 6f, p); c.drawCircle(12f, 12f, 2.2f, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    c.drawLine(12f + (6.8 * Math.cos(a)).toFloat(), 12f + (6.8 * Math.sin(a)).toFloat(),
                        12f + (9.6 * Math.cos(a)).toFloat(), 12f + (9.6 * Math.sin(a)).toFloat(), p)
                }
            }
            PREV -> {
                p.style = Paint.Style.FILL
                c.drawRect(5f, 5f, 7.5f, 19f, p)
                path.moveTo(19f, 5f); path.lineTo(9f, 12f); path.lineTo(19f, 19f); path.close(); c.drawPath(path, p)
            }
            NEXT -> {
                p.style = Paint.Style.FILL
                c.drawRect(16.5f, 5f, 19f, 19f, p)
                path.moveTo(5f, 5f); path.lineTo(15f, 12f); path.lineTo(5f, 19f); path.close(); c.drawPath(path, p)
            }
            PLAY -> {
                p.style = Paint.Style.FILL
                path.moveTo(8f, 5f); path.lineTo(19f, 12f); path.lineTo(8f, 19f); path.close(); c.drawPath(path, p)
            }
            PAUSE -> {
                p.style = Paint.Style.FILL
                c.drawRoundRect(6f, 5f, 10f, 19f, 1f, 1f, p); c.drawRoundRect(14f, 5f, 18f, 19f, 1f, 1f, p)
            }
            BT -> {
                p.style = Paint.Style.STROKE
                path.moveTo(6.5f, 7.5f); path.lineTo(17f, 17f); path.lineTo(12f, 21.5f); path.lineTo(12f, 2.5f)
                path.lineTo(17f, 7f); path.lineTo(6.5f, 16.5f); c.drawPath(path, p)
            }
            RADIO -> {
                p.style = Paint.Style.STROKE
                c.drawRoundRect(3f, 8f, 21f, 20f, 3f, 3f, p); c.drawLine(7f, 8f, 18f, 3f, p)
                c.drawCircle(16f, 14f, 2.5f, p); c.drawLine(6f, 13f, 11f, 13f, p); c.drawLine(6f, 16f, 11f, 16f, p)
            }
            SUN -> {
                p.style = Paint.Style.STROKE
                c.drawArc(RectF(7f, 9f, 17f, 19f), 180f, 180f, false, p); c.drawLine(2f, 19f, 22f, 19f, p)
                for (i in 0 until 5) {
                    val a = Math.toRadians(180.0 + i * 45.0)
                    c.drawLine(12f + (7.5 * Math.cos(a)).toFloat(), 19f + (7.5 * Math.sin(a)).toFloat(),
                        12f + (10.5 * Math.cos(a)).toFloat(), 19f + (10.5 * Math.sin(a)).toFloat(), p)
                }
            }
            CHEV -> {
                p.style = Paint.Style.STROKE
                path.moveTo(9f, 4f); path.lineTo(17f, 12f); path.lineTo(9f, 20f); c.drawPath(path, p)
            }
            PLUS -> {
                p.style = Paint.Style.STROKE
                c.drawLine(12f, 5f, 12f, 19f, p); c.drawLine(5f, 12f, 19f, 12f, p)
            }
        }
        c.restore()
    }
}

class MainActivity : Activity() {
    private val accent = Color.parseColor("#4A9EFF")
    private val gray = Color.parseColor("#9AA6BA")
    private lateinit var main: View
    private lateinit var drawer: View
    private lateinit var car: ImageView
    private lateinit var bottomRow: LinearLayout
    private lateinit var tTitle: TextView
    private lateinit var tSub: TextView
    private lateinit var art: ImageView
    private lateinit var playIcon: IconView
    private lateinit var bar: ProgressBar
    private lateinit var tHello: TextView
    private lateinit var tName: TextView
    private var ctrl: MediaController? = null
    private lateinit var carLit: ImageView
    private var lux = -1f
    private var litNow = false
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeak = false
    private var lastSpoken = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable { override fun run() { updateMedia(); updateLights(); handler.postDelayed(this, 1000) } }
    private val prefs by lazy { getSharedPreferences("vento", MODE_PRIVATE) }
    private val apps by lazy { loadApps() }
    private val defaults = listOf("com.spotify.music", "com.google.android.youtube",
        "com.google.android.projection.gearhead", "com.waze", "@bt", "@radio", "@apps")
    private val names = listOf("Spotify", "YouTube", "Android Auto", "Waze", "Bluetooth", "Radio FM", "Apps")

    class AppItem(val label: String, val icon: Drawable, val pkg: String)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun glass(r: Int = 22) = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(Color.parseColor("#26FFFFFF"), Color.parseColor("#0DFFFFFF"))).apply {
        cornerRadius = dp(r).toFloat(); setStroke(dp(1), Color.parseColor("#664A9EFF"))
    }
    private fun ring(fill: Int, stroke: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(fill); setStroke(dp(2), stroke)
    }
    private fun tv(s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun clipRound(v: View, r: Int) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: Outline) { o.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat()) }
        }
        v.clipToOutline = true
    }
    private fun launch(pkg: String) { packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#050A14"), Color.parseColor("#07101F")))
        }
        main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(topBar(), lp(-1, dp(60)))
            addView(middle(), lp(-1, 0, 1f))
            bottomRow = LinearLayout(this@MainActivity).apply { setPadding(dp(20), dp(8), dp(20), dp(16)) }
            refreshBottom()
            addView(bottomRow, lp(-1, dp(112)))
        }
        drawer = ScrollView(this).apply {
            setPadding(dp(20), dp(16), dp(20), dp(16)); visibility = View.GONE; addView(grid(apps, 6, dp(112)))
        }
        root.addView(main); root.addView(drawer)
        setContentView(root)
        initVoice()
    }

    override fun onResume() {
        super.onResume(); updateGreeting(); handler.post(poll)
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sm.getDefaultSensor(Sensor.TYPE_LIGHT)?.let { sm.registerListener(sensorL, it, SensorManager.SENSOR_DELAY_NORMAL) }
    }
    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(wakeReceiver) } catch (e: Exception) { }
        tts?.shutdown()
    }
    override fun onPause() {
        super.onPause(); handler.removeCallbacks(poll)
        (getSystemService(SENSOR_SERVICE) as SensorManager).unregisterListener(sensorL)
    }
    override fun onBackPressed() { show(true) }
    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); show(true) }
    private fun show(h: Boolean) {
        main.visibility = if (h) View.VISIBLE else View.GONE
        drawer.visibility = if (h) View.GONE else View.VISIBLE
    }

    // ---------- barra superior ----------
    private fun topBar() = FrameLayout(this).apply {
        setPadding(dp(24), 0, dp(24), 0)
        val left = LinearLayout(this@MainActivity).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(TextClock(this@MainActivity).apply {
                format12Hour = "HH:mm"; format24Hour = "HH:mm"; setTextColor(Color.WHITE); textSize = 32f
                typeface = Typeface.DEFAULT_BOLD
            })
            addView(View(this@MainActivity).apply { setBackgroundColor(Color.parseColor("#44FFFFFF")) },
                lp(dp(1), dp(26)).apply { setMargins(dp(14), 0, dp(14), 0) })
            addView(TextClock(this@MainActivity).apply {
                format12Hour = "EEE, d 'de' MMM"; format24Hour = "EEE, d 'de' MMM"; setTextColor(gray); textSize = 16f
            })
        }
        addView(left, FrameLayout.LayoutParams(-2, -1, Gravity.START))
        addView(tv("VW", 15f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; background = ring(Color.TRANSPARENT, Color.WHITE)
            setOnClickListener {
                val v = !prefs.getBoolean("voice", true); prefs.edit().putBoolean("voice", v).apply()
                Toast.makeText(this@MainActivity, if (v) "Voz de bienvenida activada" else "Voz de bienvenida desactivada", Toast.LENGTH_SHORT).show()
            }
            setOnLongClickListener { voiceMenu(); true }
        }, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))
    }

    // ---------- zona central ----------
    private fun middle() = LinearLayout(this).apply {
        setPadding(dp(24), dp(4), dp(24), dp(4))
        val col = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            addView(navCard(), lp(-1, 0, 1f).apply { bottomMargin = dp(12) })
            addView(musicCard(), lp(-1, 0, 1.45f))
        }
        addView(col, lp(0, -1, 2f).apply { rightMargin = dp(12) })
        addView(carArea(), lp(0, -1, 3f))
    }

    private fun navCard() = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; background = glass(); setPadding(dp(18), 0, dp(18), 0)
        val maps = apps.find { it.pkg == "com.google.android.apps.maps" }
        addView(if (maps != null) ImageView(this@MainActivity).apply { setImageDrawable(maps.icon) }
            else IconView(this@MainActivity, IconView.SUN, accent), lp(dp(48), dp(48)).apply { rightMargin = dp(16) })
        val t = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv("Navegación", 22f, Color.WHITE, true)); addView(tv("Google Maps • Waze", 14f, gray))
        }
        addView(t, lp(0, -2, 1f))
        addView(IconView(this@MainActivity, IconView.CHEV, Color.WHITE), lp(dp(24), dp(24)))
        setOnClickListener {
            val p = listOf("com.google.android.apps.maps", "com.waze").firstOrNull { x -> apps.any { it.pkg == x } }
            if (p != null) launch(p) else Toast.makeText(this@MainActivity, "Instala Google Maps o Waze", Toast.LENGTH_LONG).show()
        }
    }

    private fun musicCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = glass(); setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener {
                if (ctrl == null) try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
                catch (e: Exception) { Toast.makeText(this@MainActivity, "Ajustes > Acceso a notificaciones", Toast.LENGTH_LONG).show() }
            }
        }
        art = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#6A3DE8"), Color.parseColor("#1E6BFF"))).apply { cornerRadius = dp(12).toFloat() }
        }
        clipRound(art, 12)
        tTitle = tv("Mi música", 22f, Color.WHITE, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        tSub = tv("Reproduciendo", 15f, gray).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(art, lp(dp(64), dp(64)).apply { rightMargin = dp(14) })
        head.addView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(tTitle); addView(tSub) }, lp(0, -2, 1f))
        card.addView(head, lp(-1, -2))
        playIcon = IconView(this, IconView.PLAY, Color.WHITE)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        fun btn(ic: IconView, size: Int, ringIt: Boolean, f: () -> Unit) = FrameLayout(this).apply {
            if (ringIt) background = ring(Color.TRANSPARENT, Color.WHITE)
            addView(ic, FrameLayout.LayoutParams(dp(size / 2), dp(size / 2), Gravity.CENTER)); setOnClickListener { f() }
        }
        row.addView(btn(IconView(this, IconView.PREV), 48, false) { ctrl?.transportControls?.skipToPrevious() ?: key(KeyEvent.KEYCODE_MEDIA_PREVIOUS) },
            lp(dp(48), dp(48)).apply { setMargins(dp(14), 0, dp(14), 0) })
        row.addView(btn(playIcon, 60, true) { playPause() }, lp(dp(60), dp(60)).apply { setMargins(dp(14), 0, dp(14), 0) })
        row.addView(btn(IconView(this, IconView.NEXT), 48, false) { ctrl?.transportControls?.skipToNext() ?: key(KeyEvent.KEYCODE_MEDIA_NEXT) },
            lp(dp(48), dp(48)).apply { setMargins(dp(14), 0, dp(14), 0) })
        card.addView(row, lp(-1, 0, 1f))
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000; progress = 0
            progressTintList = ColorStateList.valueOf(accent)
            progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#44FFFFFF"))
        }
        card.addView(bar, lp(-1, dp(6)))
        return card
    }

    private fun carArea(): View {
        val f = FrameLayout(this)
        car = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(0, dp(56), 0, 0) }
        val saved = File(filesDir, "car.png")
        val bmp = if (saved.exists()) decode(saved) else null
        if (bmp != null) car.setImageBitmap(bmp) else car.setImageResource(R.drawable.vento_off)
        f.addView(car)
        carLit = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(0, dp(56), 0, 0); alpha = 0f }
        if (bmp == null) carLit.setImageResource(R.drawable.vento_mock)
        f.addView(carLit)
        tHello = tv("", 20f, Color.WHITE)
        tName = tv("", 32f, Color.WHITE, true).apply { setTypeface(Typeface.DEFAULT_BOLD, Typeface.ITALIC) }
        val g = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(IconView(this@MainActivity, IconView.SUN, accent), lp(dp(40), dp(40)).apply { rightMargin = dp(12) })
            addView(LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; addView(tHello); addView(tName) })
            setOnLongClickListener { askName(); true }
        }
        f.addView(g, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(4), dp(12), 0) })
        f.setOnLongClickListener { pickPhoto(); true }
        f.setOnClickListener { cycleLights() }
        return f
    }

    private fun updateGreeting() {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        tHello.text = if (h < 12) "¡Buenos días," else if (h < 19) "¡Buenas tardes," else "¡Buenas noches,"
        tName.text = (prefs.getString("name", "José Luis") ?: "José Luis") + "!"
    }

    private fun askName() {
        val et = EditText(this).apply { setText(prefs.getString("name", "José Luis")) }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Tu nombre").setView(et)
            .setPositiveButton("Guardar") { _, _ -> prefs.edit().putString("name", et.text.toString().trim()).apply(); updateGreeting() }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun pickPhoto() {
        try { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1) }
        catch (e: Exception) { Toast.makeText(this, "No hay galería o explorador de archivos", Toast.LENGTH_LONG).show() }
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r != 1 || c != RESULT_OK) return
        val uri = d?.data ?: return
        try {
            val f = File(filesDir, "car.png")
            contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            decode(f)?.let { car.setImageBitmap(it) }
        } catch (e: Exception) { Toast.makeText(this, "No se pudo cargar la imagen", Toast.LENGTH_LONG).show() }
    }

    private fun decode(f: File): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > 2000) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    // ---------- luces del auto ----------
    private val sensorL = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) { lux = e.values[0] }
        override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    }

    private fun lightsWanted(): Boolean = when (prefs.getInt("lights", 0)) {
        1 -> true
        2 -> false
        3 -> java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY).let { it >= 19 || it < 6 }
        else -> (lux in 0f..15f) ||
            (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun updateLights() {
        val on = lightsWanted()
        if (on != litNow) { litNow = on; carLit.animate().alpha(if (on) 1f else 0f).setDuration(700).start() }
    }

    private fun cycleLights() {
        val m = (prefs.getInt("lights", 0) + 1) % 4
        prefs.edit().putInt("lights", m).apply()
        Toast.makeText(this, listOf("Luces: automático (sensor o modo nocturno)", "Luces: siempre encendidas",
            "Luces: siempre apagadas", "Luces: por horario (7 pm a 6 am)")[m], Toast.LENGTH_SHORT).show()
        updateLights()
    }

    // ---------- voz de bienvenida ----------
    private val wakeReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { speakWelcome(false) }
    }

    private fun initVoice() {
        tts = TextToSpeech(this) { st ->
            val t = tts
            if (st == TextToSpeech.SUCCESS && t != null) {
                if (t.setLanguage(Locale("es", "MX")) < TextToSpeech.LANG_AVAILABLE) t.setLanguage(Locale("es"))
                applyVoicePrefs()
                ttsReady = true
                if (pendingSpeak) { pendingSpeak = false; speakWelcome(false) }
            }
        }
        registerReceiver(wakeReceiver, IntentFilter(Intent.ACTION_SCREEN_ON))
        speakWelcome(false)
    }

    private fun speakWelcome(force: Boolean) {
        if (!force && !prefs.getBoolean("voice", true)) return
        val now = SystemClock.elapsedRealtime()
        if (!force && lastSpoken != 0L && now - lastSpoken < 30000) return
        if (!ttsReady) { pendingSpeak = true; return }
        lastSpoken = now
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val hi = if (h < 12) "Buenos días" else if (h < 19) "Buenas tardes" else "Buenas noches"
        val name = prefs.getString("name", "José Luis")
        val msgs = listOf(
            "Recuerda abrochar tu cinturón y respetar los límites de velocidad.",
            "Maneja con calma, guarda la distancia con el auto de enfrente y no uses el celular mientras conduces.",
            "Revisa tus espejos antes de arrancar. Llegar con bien es lo más importante.",
            "Antes de arrancar, confirma que todos los pasajeros traigan el cinturón puesto.",
            "Si vas a tomar, no manejes. Cuida tu vida y la de los demás."
        )
        val text = "$hi, $name. Bienvenido a bordo. ${msgs.random()}"
        handler.postDelayed({ tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "welcome") }, if (force) 0L else 2500L)
    }

    // ---------- menu de voz ----------
    private fun applyVoicePrefs() {
        val t = tts ?: return
        t.setSpeechRate(prefs.getFloat("rate", 1f)); t.setPitch(prefs.getFloat("pitch", 1f))
        val n = prefs.getString("voiceName", null)
        if (n != null) t.voices?.find { it.name == n }?.let { v -> t.setVoice(v) }
    }

    private fun sample() {
        tts?.speak("Hola, así suena esta voz. Bienvenido a bordo.", TextToSpeech.QUEUE_FLUSH, null, "sample")
    }

    private fun openTtsSettings() {
        try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
        catch (e: Exception) { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e2: Exception) { } }
    }

    private fun dlg() = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun voiceMenu() {
        val items = arrayOf("Probar voz", "Elegir voz", "Velocidad", "Tono", "Más voces (ajustes del sistema)")
        dlg().setTitle("Voz del asistente").setItems(items) { _, w ->
            when (w) {
                0 -> speakWelcome(true)
                1 -> voicePicker()
                2 -> pickFloat("Velocidad", arrayOf("Lenta", "Normal", "Rápida"), floatArrayOf(0.8f, 1f, 1.2f), "rate")
                3 -> pickFloat("Tono", arrayOf("Grave", "Normal", "Agudo"), floatArrayOf(0.85f, 1f, 1.15f), "pitch")
                else -> openTtsSettings()
            }
        }.show()
    }

    private fun pickFloat(title: String, labels: Array<String>, vals: FloatArray, key: String) {
        dlg().setTitle(title).setItems(labels) { _, w ->
            prefs.edit().putFloat(key, vals[w]).apply(); applyVoicePrefs(); sample()
        }.show()
    }

    private fun voicePicker() {
        val vs = (tts?.voices ?: emptySet()).filter { it.locale.language == "es" }.sortedBy { it.name }
        if (vs.isEmpty()) {
            Toast.makeText(this, "Tu radio no ofrece voces en español. Instala Servicios de voz de Google.", Toast.LENGTH_LONG).show()
            openTtsSettings(); return
        }
        val cur = prefs.getString("voiceName", null) ?: tts?.voice?.name
        val labels = vs.mapIndexed { i, v ->
            "Voz ${i + 1} · " + v.locale.displayCountry.ifEmpty { v.locale.displayLanguage } +
                (if (v.isNetworkConnectionRequired) " (necesita internet)" else "")
        }.toTypedArray()
        dlg().setTitle("Elegir voz (toca para escuchar)")
            .setSingleChoiceItems(labels, vs.indexOfFirst { it.name == cur }) { _, w ->
                prefs.edit().putString("voiceName", vs[w].name).apply(); tts?.setVoice(vs[w]); sample()
            }
            .setPositiveButton("Listo", null).show()
    }

    // ---------- musica ----------
    private fun key(code: Int) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun playPause() {
        val c = ctrl
        if (c == null) { key(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); return }
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause() else c.transportControls.play()
    }

    private fun updateMedia() {
        try {
            val msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(this, MediaListener::class.java))
            ctrl = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
            val md = ctrl?.metadata
            if (md == null) {
                tTitle.text = "Mi música"; tSub.text = "Abre Spotify o YouTube Music"
                art.setImageDrawable(null); playIcon.kind = IconView.PLAY; playIcon.invalidate(); bar.progress = 0
                return
            }
            tTitle.text = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Sin título"
            tSub.text = md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "Reproduciendo"
            val bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            if (bmp != null) art.setImageBitmap(bmp) else art.setImageDrawable(null)
            val ps = ctrl?.playbackState
            val playing = ps?.state == PlaybackState.STATE_PLAYING
            playIcon.kind = if (playing) IconView.PAUSE else IconView.PLAY; playIcon.invalidate()
            val dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION)
            if (ps != null && dur > 0) {
                var pos = ps.position
                if (playing) pos += ((SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * ps.playbackSpeed).toLong()
                bar.progress = (1000L * pos / dur).coerceIn(0L, 1000L).toInt()
            } else bar.progress = 0
        } catch (e: SecurityException) {
            ctrl = null; tTitle.text = "Activar música en pantalla"; tSub.text = "Toca aquí y permite el acceso"
        } catch (e: Exception) { }
    }

    // ---------- accesos de abajo ----------
    private fun slots(): MutableList<String> {
        val s = prefs.getString("slots", null)?.split(",")?.toMutableList() ?: defaults.toMutableList()
        while (s.size < 7) s.add(defaults[s.size])
        return s.take(7).toMutableList()
    }

    private fun resolve(t: String): AppItem? = when {
        t == "@radio" -> apps.find { Regex("radio|\\bfm\\b", RegexOption.IGNORE_CASE).containsMatchIn(it.label) }
        t.startsWith("@") -> null
        else -> apps.find { it.pkg == t }
    }

    private fun refreshBottom() {
        bottomRow.removeAllViews()
        val sl = slots()
        for (i in 0 until 7) {
            val t = sl[i]; val a = resolve(t)
            val v = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = glass(20)
                val special = t.startsWith("@")
                if (a != null && t != "@apps") addView(ImageView(this@MainActivity).apply { setImageDrawable(a.icon) }, lp(dp(46), dp(46)))
                else addView(IconView(this@MainActivity, when (t) { "@bt" -> IconView.BT; "@apps" -> IconView.APPS
                    "@radio" -> IconView.RADIO; else -> IconView.PLUS }, if (t.startsWith("@")) Color.WHITE else gray), lp(dp(40), dp(40)))
                addView(tv(if (a != null && !special) a.label else names[i], 14f).apply {
                    gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(4), 0, 0)
                })
                setOnClickListener {
                    when {
                        t == "@bt" -> try { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } catch (e: Exception) { }
                        t == "@apps" -> show(false)
                        a != null -> launch(a.pkg)
                        else -> chooseApp(i)
                    }
                }
                setOnLongClickListener { chooseApp(i); true }
            }
            bottomRow.addView(v, lp(0, -1, 1f).apply { setMargins(dp(5), 0, dp(5), 0) })
        }
    }

    private fun chooseApp(i: Int) {
        val labels = apps.map { it.label }.toTypedArray()
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Elegir app para este botón")
            .setItems(labels) { _, w -> val l = slots(); l[i] = apps[w].pkg; prefs.edit().putString("slots", l.joinToString(",")).apply(); refreshBottom() }
            .setNeutralButton("Restaurar") { _, _ -> val l = slots(); l[i] = defaults[i]; prefs.edit().putString("slots", l.joinToString(",")).apply(); refreshBottom() }
            .setNegativeButton("Cancelar", null).show()
    }

    // ---------- todas las apps ----------
    private fun tile(a: AppItem): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = glass(20)
        addView(ImageView(this@MainActivity).apply { setImageDrawable(a.icon) }, lp(dp(52), dp(52)))
        addView(tv(a.label, 12f).apply { gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(dp(4), dp(4), dp(4), 0) })
        setOnClickListener { launch(a.pkg) }
    }

    private fun grid(items: List<AppItem>, cols: Int, rowH: Int): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        items.chunked(cols).forEach { chunk ->
            val r = LinearLayout(this)
            for (i in 0 until cols) r.addView(if (i < chunk.size) tile(chunk[i]) else View(this), lp(0, -1, 1f).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) })
            box.addView(r, lp(-1, rowH))
        }
        return box
    }

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.loadIcon(pm), it.activityInfo.packageName) }
            .sortedBy { it.label.lowercase() }
    }
}
