package com.vento.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.*
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private val accent = Color.parseColor("#4A9EFF")   // azul frio
    private val card = Color.parseColor("#151C28")
    private val gray = Color.parseColor("#8A94A6")
    private lateinit var home: View
    private lateinit var drawer: View
    private lateinit var car: ImageView
    private val apps by lazy { loadApps() }

    class AppItem(val label: String, val icon: Drawable, val pkg: String)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun rounded(color: Int, r: Int = 20) =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun tv(s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#0B0F17"), Color.parseColor("#12203A"))
            )
        }
        home = buildHome()
        drawer = buildDrawer()
        drawer.visibility = View.GONE
        val content = FrameLayout(this).apply { addView(home); addView(drawer) }
        root.addView(sidebar(), lp(dp(92), -1))
        root.addView(content, lp(0, -1, 1f))
        setContentView(root)
    }

    private fun show(homeVisible: Boolean) {
        home.visibility = if (homeVisible) View.VISIBLE else View.GONE
        drawer.visibility = if (homeVisible) View.GONE else View.VISIBLE
    }

    override fun onBackPressed() { show(true) }
    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); show(true) }

    private fun navBtn(label: String, onClick: () -> Unit) = tv(label, 14f, accent, true).apply {
        gravity = Gravity.CENTER
        background = rounded(card, 18)
        layoutParams = lp(dp(72), dp(56)).apply { bottomMargin = dp(12) }
        setOnClickListener { onClick() }
    }

    private fun sidebar() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(0, dp(16), 0, dp(16))
        setBackgroundColor(Color.parseColor("#080B12"))
        addView(navBtn("Inicio") { show(true) })
        addView(navBtn("Apps") { show(false) })
        addView(navBtn("Ajustes") { startActivity(Intent(Settings.ACTION_SETTINGS)) })
        addView(View(this@MainActivity), lp(1, 0, 1f))
        addView(TextClock(this@MainActivity).apply {
            format12Hour = "h:mm"; format24Hour = "HH:mm"
            setTextColor(Color.WHITE); textSize = 18f
        })
    }

    private fun buildHome(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        row.addView(carCard(), lp(0, -1, 3f).apply { rightMargin = dp(16) })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(playerCard(), lp(-1, 0, 1f).apply { bottomMargin = dp(16) })
        col.addView(grid(quick(), 3, 0), lp(-1, 0, 1.4f))
        row.addView(col, lp(0, -1, 2f))
        return row
    }

    private fun carCard(): View {
        val f = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#1B2638"), Color.parseColor("#0E141F"))
            ).apply { cornerRadius = dp(24).toFloat() }
        }
        car = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(24), dp(70), dp(24), dp(60))
        }
        val saved = File(filesDir, "car.png")
        val bmp = if (saved.exists()) decode(saved) else null
        if (bmp != null) car.setImageBitmap(bmp) else car.setImageResource(R.drawable.vento)
        f.addView(car)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextClock(this@MainActivity).apply {
                format12Hour = "h:mm"; format24Hour = "HH:mm"
                setTextColor(Color.WHITE); textSize = 40f; typeface = Typeface.DEFAULT_BOLD
            })
            addView(TextClock(this@MainActivity).apply {
                format12Hour = "EEEE d 'de' MMMM"; format24Hour = "EEEE d 'de' MMMM"
                setTextColor(gray); textSize = 16f
            })
        }
        f.addView(top, FrameLayout.LayoutParams(-2, -2).apply { setMargins(dp(24), dp(20), 0, 0) })

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv("Volkswagen Vento Starline 2015", 18f, Color.WHITE, true))
            addView(tv("Manten presionado para cambiar la foto", 12f, gray))
        }
        f.addView(bottom, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM).apply {
            setMargins(dp(24), 0, 0, dp(18))
        })
        f.setOnLongClickListener { pickPhoto(); true }
        return f
    }

    private fun pickPhoto() {
        try {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1)
        } catch (e: Exception) {
            Toast.makeText(this, "No hay galeria o explorador de archivos", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r != 1 || c != RESULT_OK) return
        val uri = d?.data ?: return
        try {
            val f = File(filesDir, "car.png")
            contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            decode(f)?.let { car.setImageBitmap(it) }
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo cargar la imagen", Toast.LENGTH_LONG).show()
        }
    }

    private fun decode(f: File): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > 2000) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private fun key(code: Int) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun ctrl(label: String, code: Int) = tv(label, 15f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER
        background = rounded(accent, 16)
        setOnClickListener { key(code) }
    }

    private fun playerCard() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = rounded(card, 24)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        addView(tv("Reproduciendo", 13f, gray))
        addView(tv("Controles de musica", 20f, Color.WHITE, true))
        val r = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER }
        r.addView(ctrl("Anterior", KeyEvent.KEYCODE_MEDIA_PREVIOUS), lp(0, dp(48), 1f).apply { setMargins(0, dp(14), dp(8), 0) })
        r.addView(ctrl("Play / Pausa", KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE), lp(0, dp(48), 1.3f).apply { setMargins(0, dp(14), dp(8), 0) })
        r.addView(ctrl("Siguiente", KeyEvent.KEYCODE_MEDIA_NEXT), lp(0, dp(48), 1f).apply { topMargin = dp(14) })
        addView(r, lp(-1, -2))
    }

    private fun tile(a: AppItem): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = rounded(card, 18)
        setPadding(dp(6), dp(8), dp(6), dp(8))
        addView(ImageView(this@MainActivity).apply { setImageDrawable(a.icon) }, lp(dp(56), dp(56)))
        addView(tv(a.label, 12f).apply {
            gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        })
        setOnClickListener {
            packageManager.getLaunchIntentForPackage(a.pkg)?.let { i -> startActivity(i) }
        }
    }

    // rowH = 0 -> las filas se reparten el alto disponible
    private fun grid(items: List<AppItem>, cols: Int, rowH: Int): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        items.chunked(cols).forEach { chunk ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in 0 until cols) {
                val v = if (i < chunk.size) tile(chunk[i]) else View(this)
                r.addView(v, lp(0, -1, 1f).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) })
            }
            box.addView(r, if (rowH > 0) lp(-1, rowH) else lp(-1, 0, 1f))
        }
        return box
    }

    private fun buildDrawer(): View = ScrollView(this).apply {
        setPadding(dp(16), dp(16), dp(16), dp(16))
        addView(grid(apps, 6, dp(110)))
    }

    private fun quick(): List<AppItem> {
        val fav = listOf(
            "com.google.android.apps.maps", "com.waze", "com.spotify.music",
            "com.google.android.apps.youtube.music", "com.google.android.youtube", "com.android.chrome"
        )
        return fav.mapNotNull { p -> apps.find { it.pkg == p } }.take(6).ifEmpty { apps.take(6) }
    }

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.loadIcon(pm), it.activityInfo.packageName) }
            .sortedBy { it.label.lowercase() }
    }
}
