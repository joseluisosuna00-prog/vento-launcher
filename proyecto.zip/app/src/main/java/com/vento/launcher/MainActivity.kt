package com.vento.launcher

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.os.SystemClock
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.*
import android.widget.*
import java.io.File
import java.util.Locale
import java.net.HttpURLConnection
import java.net.URL
import android.bluetooth.BluetoothAdapter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.Manifest
import android.animation.ValueAnimator
import android.content.pm.PackageManager
import android.net.Uri
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.animation.LinearInterpolator
import java.text.SimpleDateFormat
import kotlin.math.sin
import kotlin.math.exp
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.res.Configuration
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.speech.tts.TextToSpeech

/** Iconos dibujados con codigo (no dependen de fuentes ni de imagenes). */
class IconView(ctx: Context, var kind: Int, var tint: Int = Color.WHITE) : View(ctx) {
    companion object {
        const val HOME = 0; const val APPS = 1; const val GEAR = 2; const val PREV = 3
        const val PLAY = 4; const val PAUSE = 5; const val NEXT = 6; const val PLUS = 7; const val BT = 8; const val RADIO = 9; const val SUN = 10; const val CHEV = 11; const val MIC = 12; const val WIFI = 13; const val SIGNAL = 14; const val WAVE = 15; const val CLOUD = 16; const val MUSIC = 17; const val NAVI = 18; const val PHONE = 19; const val CARI = 20; const val SHUFFLE = 21; const val REPEAT = 22; const val HEART = 23; const val USB = 24
    }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        c.save()
        c.translate((width - s) / 2, (height - s) / 2)
        c.scale(s / 24f, s / 24f)
        p.color = tint; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND; p.strokeWidth = 2f
        val path = Path()
        when (kind) {
            HOME -> {
                p.style = Paint.Style.STROKE
                path.moveTo(3f, 11f); path.lineTo(12f, 3f); path.lineTo(21f, 11f)
                path.moveTo(5.5f, 9.5f); path.lineTo(5.5f, 20f); path.lineTo(10f, 20f); path.lineTo(10f, 14f)
                path.lineTo(14f, 14f); path.lineTo(14f, 20f); path.lineTo(18.5f, 20f); path.lineTo(18.5f, 9.5f)
                c.drawPath(path, p)
            }
            APPS -> {
                p.style = Paint.Style.FILL
                for ((x, y) in listOf(4f to 4f, 14f to 4f, 4f to 14f, 14f to 14f)) c.drawRoundRect(x, y, x + 6f, y + 6f, 1.5f, 1.5f, p)
            }
            GEAR -> {
                p.style = Paint.Style.STROKE
                c.drawCircle(12f, 12f, 6f, p); c.drawCircle(12f, 12f, 2.2f, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    c.drawLine(12f + (6.8 * Math.cos(a)).toFloat(), 12f + (6.8 * Math.sin(a)).toFloat(),
                        12f + (9.6 * Math.cos(a)).toFloat(), 12f + (9.6 * Math.sin(a)).toFloat(), p)
                }
            }
            PREV -> {
                p.style = Paint.Style.FILL
                c.drawRect(5f, 5f, 7.5f, 19f, p)
                path.moveTo(19f, 5f); path.lineTo(9f, 12f); path.lineTo(19f, 19f); path.close(); c.drawPath(path, p)
            }
            NEXT -> {
                p.style = Paint.Style.FILL
                c.drawRect(16.5f, 5f, 19f, 19f, p)
                path.moveTo(5f, 5f); path.lineTo(15f, 12f); path.lineTo(5f, 19f); path.close(); c.drawPath(path, p)
            }
            PLAY -> {
                p.style = Paint.Style.FILL
                path.moveTo(8f, 5f); path.lineTo(19f, 12f); path.lineTo(8f, 19f); path.close(); c.drawPath(path, p)
            }
            PAUSE -> {
                p.style = Paint.Style.FILL
                c.drawRoundRect(6f, 5f, 10f, 19f, 1f, 1f, p); c.drawRoundRect(14f, 5f, 18f, 19f, 1f, 1f, p)
            }
            BT -> {
                p.style = Paint.Style.STROKE
                path.moveTo(6.5f, 7.5f); path.lineTo(17f, 17f); path.lineTo(12f, 21.5f); path.lineTo(12f, 2.5f)
                path.lineTo(17f, 7f); path.lineTo(6.5f, 16.5f); c.drawPath(path, p)
            }
            RADIO -> {
                p.style = Paint.Style.STROKE
                c.drawRoundRect(3f, 8f, 21f, 20f, 3f, 3f, p); c.drawLine(7f, 8f, 18f, 3f, p)
                c.drawCircle(16f, 14f, 2.5f, p); c.drawLine(6f, 13f, 11f, 13f, p); c.drawLine(6f, 16f, 11f, 16f, p)
            }
            SUN -> {
                p.style = Paint.Style.STROKE
                c.drawArc(RectF(7f, 9f, 17f, 19f), 180f, 180f, false, p); c.drawLine(2f, 19f, 22f, 19f, p)
                for (i in 0 until 5) {
                    val a = Math.toRadians(180.0 + i * 45.0)
                    c.drawLine(12f + (7.5 * Math.cos(a)).toFloat(), 19f + (7.5 * Math.sin(a)).toFloat(),
                        12f + (10.5 * Math.cos(a)).toFloat(), 19f + (10.5 * Math.sin(a)).toFloat(), p)
                }
            }
            CHEV -> {
                p.style = Paint.Style.STROKE
                path.moveTo(9f, 4f); path.lineTo(17f, 12f); path.lineTo(9f, 20f); c.drawPath(path, p)
            }
            CLOUD -> {
                p.style = Paint.Style.FILL
                c.drawCircle(8.5f, 14f, 4f, p); c.drawCircle(13.5f, 11f, 5f, p); c.drawCircle(18f, 14.5f, 3.5f, p); c.drawRoundRect(5f, 14f, 21.5f, 18.5f, 2f, 2f, p)
            }
            MUSIC -> {
                p.style = Paint.Style.STROKE
                path.moveTo(9f, 17f); path.lineTo(9f, 6f); path.lineTo(19f, 4f); path.lineTo(19f, 15f); c.drawPath(path, p)
                p.style = Paint.Style.FILL; c.drawCircle(6.8f, 17.5f, 2.8f, p); c.drawCircle(16.8f, 15.5f, 2.8f, p)
            }
            NAVI -> {
                p.style = Paint.Style.STROKE
                path.moveTo(3f, 11f); path.lineTo(21f, 3f); path.lineTo(13f, 21f); path.lineTo(11f, 13f); path.close(); c.drawPath(path, p)
            }
            PHONE -> {
                p.style = Paint.Style.STROKE
                path.moveTo(6f, 3f); path.lineTo(10f, 3f); path.lineTo(11.5f, 8f); path.lineTo(9.2f, 9.6f); path.quadTo(10.6f, 13.4f, 14.4f, 14.8f)
                path.lineTo(16f, 12.5f); path.lineTo(21f, 14f); path.lineTo(21f, 18f); path.quadTo(21f, 21f, 18f, 21f); path.quadTo(4f, 20f, 3f, 6f)
                path.quadTo(3f, 3f, 6f, 3f); path.close(); c.drawPath(path, p)
            }
            CARI -> {
                p.style = Paint.Style.STROKE
                c.drawRoundRect(3f, 11f, 21f, 18f, 3f, 3f, p)
                path.moveTo(5f, 11f); path.lineTo(7.5f, 6f); path.lineTo(16.5f, 6f); path.lineTo(19f, 11f); c.drawPath(path, p)
                p.style = Paint.Style.FILL; c.drawCircle(7.5f, 18f, 2f, p); c.drawCircle(16.5f, 18f, 2f, p)
            }
            SHUFFLE -> {
                p.style = Paint.Style.STROKE
                path.moveTo(3f, 7f); path.lineTo(8f, 7f); path.lineTo(15f, 17f); path.lineTo(19f, 17f)
                path.moveTo(3f, 17f); path.lineTo(8f, 17f); path.lineTo(15f, 7f); path.lineTo(19f, 7f); c.drawPath(path, p)
                p.style = Paint.Style.FILL
                val a1 = Path(); a1.moveTo(21.5f, 7f); a1.lineTo(18f, 4.5f); a1.lineTo(18f, 9.5f); a1.close(); c.drawPath(a1, p)
                val a2 = Path(); a2.moveTo(21.5f, 17f); a2.lineTo(18f, 14.5f); a2.lineTo(18f, 19.5f); a2.close(); c.drawPath(a2, p)
            }
            REPEAT -> {
                p.style = Paint.Style.STROKE
                path.moveTo(7f, 6f); path.lineTo(17f, 6f); path.quadTo(21f, 6f, 21f, 10f); path.lineTo(21f, 11f)
                path.moveTo(17f, 18f); path.lineTo(7f, 18f); path.quadTo(3f, 18f, 3f, 14f); path.lineTo(3f, 13f); c.drawPath(path, p)
                p.style = Paint.Style.FILL
                val a1 = Path(); a1.moveTo(15f, 2.5f); a1.lineTo(19f, 6f); a1.lineTo(15f, 9.5f); a1.close(); c.drawPath(a1, p)
                val a2 = Path(); a2.moveTo(9f, 14.5f); a2.lineTo(5f, 18f); a2.lineTo(9f, 21.5f); a2.close(); c.drawPath(a2, p)
            }
            HEART -> {
                p.style = Paint.Style.STROKE
                path.moveTo(12f, 20.5f); path.cubicTo(3f, 14f, 3.5f, 6f, 8.5f, 5.5f); path.cubicTo(10.5f, 5.3f, 11.7f, 6.5f, 12f, 7.5f)
                path.cubicTo(12.3f, 6.5f, 13.5f, 5.3f, 15.5f, 5.5f); path.cubicTo(20.5f, 6f, 21f, 14f, 12f, 20.5f); c.drawPath(path, p)
            }
            USB -> {
                p.style = Paint.Style.STROKE
                c.drawLine(12f, 19f, 12f, 6f, p); c.drawRoundRect(9.5f, 2.5f, 14.5f, 6f, 1f, 1f, p)
                c.drawLine(12f, 13f, 7f, 10f, p); c.drawLine(12f, 16f, 17f, 12.5f, p)
                p.style = Paint.Style.FILL; c.drawCircle(12f, 20f, 2f, p); c.drawCircle(6.5f, 9.5f, 1.6f, p); c.drawRect(16f, 10.8f, 19f, 13.8f, p)
            }
            WIFI -> {
                p.style = Paint.Style.STROKE
                for (r in listOf(4f, 8f, 12f)) c.drawArc(RectF(12f - r, 19f - r, 12f + r, 19f + r), 225f, 90f, false, p)
                p.style = Paint.Style.FILL; c.drawCircle(12f, 19f, 1.4f, p)
            }
            SIGNAL -> {
                p.style = Paint.Style.FILL
                for ((i, h) in listOf(5f, 9f, 13f, 17f).withIndex()) c.drawRoundRect(3f + i * 5f, 20f - h, 6f + i * 5f, 20f, 1f, 1f, p)
            }
            WAVE -> {
                p.style = Paint.Style.FILL
                for ((i, h) in listOf(6f, 12f, 20f, 11f, 5f).withIndex()) c.drawRoundRect(3f + i * 4.5f, 12f - h / 2, 5.4f + i * 4.5f, 12f + h / 2, 1.2f, 1.2f, p)
            }
            MIC -> {
                p.style = Paint.Style.STROKE
                c.drawRoundRect(9f, 3f, 15f, 13f, 3f, 3f, p); c.drawArc(RectF(6f, 7f, 18f, 17f), 0f, 180f, false, p)
                c.drawLine(12f, 17f, 12f, 21f, p); c.drawLine(9f, 21f, 15f, 21f, p)
            }
            PLUS -> {
                p.style = Paint.Style.STROKE
                c.drawLine(12f, 5f, 12f, 19f, p); c.drawLine(5f, 12f, 19f, 12f, p)
            }
        }
        c.restore()
    }
}

/** Esfera del asistente: 0 = en espera, 1 = escuchando, 2 = respondiendo. */
class OrbView(ctx: Context) : View(ctx) {
    var mode = 0
    var level = 0f
    private var t = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pi2 = (2 * Math.PI).toFloat()
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedFraction; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    private fun glowRing(c: Canvas, cx: Float, cy: Float, rad: Float, w: Float, col: Int, a: Int) {
        p.style = Paint.Style.STROKE; p.shader = null
        for (k in 5 downTo 1) { p.color = col; p.alpha = a / (k + 1); p.strokeWidth = w + k * w * 0.9f; c.drawCircle(cx, cy, rad, p) }
        p.color = col; p.alpha = 255; p.strokeWidth = w; c.drawCircle(cx, cy, rad, p)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) / 2f
        val s = sin(t * pi2)
        when (mode) {
            0 -> {
                glowRing(c, cx, cy, r * 0.72f, r * 0.04f, Color.parseColor("#6AB0FF"), 90)
                p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.05f; p.color = Color.WHITE; p.alpha = 255
                c.drawCircle(cx, cy, r * 0.72f, p)
            }
            1 -> {
                p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.02f
                for (i in 0 until 3) {
                    val f = (t + i / 3f) % 1f
                    p.color = Color.parseColor("#4A9EFF"); p.alpha = ((1 - f) * 110).toInt()
                    c.drawCircle(cx, cy, r * (0.4f + 0.55f * f), p)
                }
                val rr = r * 0.4f * (1f + 0.06f * s + 0.35f * level)
                p.style = Paint.Style.FILL; p.alpha = 255
                p.shader = RadialGradient(cx, cy, rr,
                    intArrayOf(Color.parseColor("#C58BFF"), Color.parseColor("#3A7BFF"), Color.parseColor("#12235E"), Color.TRANSPARENT),
                    floatArrayOf(0f, 0.45f, 0.85f, 1f), Shader.TileMode.CLAMP)
                c.drawCircle(cx, cy, rr, p); p.shader = null
            }
            else -> {
                glowRing(c, cx, cy, r * 0.82f, r * 0.06f, Color.parseColor("#1E6BFF"), 140)
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#04101F"); p.alpha = 255
                c.drawCircle(cx, cy, r * 0.66f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.025f; p.color = Color.parseColor("#3FD0FF")
                c.drawCircle(cx, cy, r * 0.66f, p)
                val w = r * 1.1f; val path = Path()
                for ((k, col) in listOf("#FFFFFF", "#3FD0FF", "#6A8CFF").withIndex()) {
                    path.reset()
                    for (x in 0..60) {
                        val u = x / 60f; val px = cx - w / 2 + w * u; val env = 1 - (2 * u - 1) * (2 * u - 1)
                        val py = cy + env * r * 0.2f * (0.5f + 0.5f * sin(t * pi2 * (k + 1) + u * 6f + k)) * sin(u * 12f + t * pi2)
                        if (x == 0) path.moveTo(px, py) else path.lineTo(px, py)
                    }
                    p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.018f; p.color = Color.parseColor(col); p.alpha = if (k == 0) 255 else 160
                    c.drawPath(path, p)
                }
            }
        }
    }
}

/** Fondo decorativo tipo mapa para la tarjeta de navegacion. */
class MapBgView(ctx: Context) : View(ctx) {
    var day = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        p.color = Color.parseColor(if (day) "#1A2A4A7A" else "#14FFFFFF"); p.strokeWidth = h * 0.012f
        for (i in 1..4) c.drawLine(w * (0.2f + 0.17f * i), 0f, w * (0.05f + 0.17f * i), h, p)
        for (i in 1..3) c.drawLine(w * 0.3f, h * 0.22f * i, w, h * (0.22f * i + 0.12f), p)
        val route = Path().apply { moveTo(w * 0.52f, h); cubicTo(w * 0.62f, h * 0.7f, w * 0.78f, h * 0.55f, w * 0.88f, h * 0.14f) }
        p.color = Color.parseColor("#554A9EFF"); p.strokeWidth = h * 0.05f; c.drawPath(route, p)
        p.color = Color.parseColor("#4A9EFF"); p.strokeWidth = h * 0.022f; c.drawPath(route, p)
        p.style = Paint.Style.FILL; p.color = if (day) Color.parseColor("#1E7BFF") else Color.WHITE
        val a = Path().apply { moveTo(w * 0.88f, h * 0.04f); lineTo(w * 0.92f, h * 0.2f); lineTo(w * 0.88f, h * 0.16f); lineTo(w * 0.84f, h * 0.2f); close() }
        c.drawPath(a, p)
    }
}

/** Capa de bienvenida: reproduce el video (imagen y sonido ya vienen sincronizados) centrado y sin deformarlo. */
class SplashLayer(ctx: Context) : FrameLayout(ctx) {
    val video = VideoView(ctx)
    init { setBackgroundColor(Color.BLACK); isClickable = true; addView(video, LayoutParams(-1, -1)) }
    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec); val h = MeasureSpec.getSize(hSpec)
        val vw = minOf(w.toFloat(), h * 16f / 9f).toInt(); val vh = (vw * 9f / 16f).toInt()
        video.measure(MeasureSpec.makeMeasureSpec(vw, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(vh, MeasureSpec.EXACTLY))
        setMeasuredDimension(w, h)
    }
    override fun onLayout(c: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val vw = video.measuredWidth; val vh = video.measuredHeight
        val x = (r - l - vw) / 2; val y = (b - t - vh) / 2
        video.layout(x, y, x + vw, y + vh)
    }
}

/** Barra de progreso arrastrable. */
class SeekView(ctx: Context) : View(ctx) {
    var progress = 0f
    var accent = Color.BLUE
    var track = Color.GRAY
    var dragging = false
    var onSeek: ((Float) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val h = height / 2f; val th = height * 0.14f; val pad = height * 0.35f; val w = width - 2 * pad
        p.style = Paint.Style.FILL; p.color = track; c.drawRoundRect(pad, h - th / 2, pad + w, h + th / 2, th, th, p)
        p.color = accent; c.drawRoundRect(pad, h - th / 2, pad + w * progress, h + th / 2, th, th, p)
        p.color = Color.WHITE; c.drawCircle(pad + w * progress, h, height * 0.30f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = height * 0.10f; p.color = accent; c.drawCircle(pad + w * progress, h, height * 0.30f, p)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val pad = height * 0.35f; val f = ((e.x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { dragging = true; progress = f; invalidate(); parent.requestDisallowInterceptTouchEvent(true) }
            MotionEvent.ACTION_MOVE -> { progress = f; invalidate() }
            MotionEvent.ACTION_UP -> { dragging = false; progress = f; invalidate(); onSeek?.invoke(f) }
            MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }
}

/** Linea azul inferior con el emblema al centro. */
class BaseLineView(ctx: Context, private val accent: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true }
    private val logo = BitmapFactory.decodeResource(resources, R.drawable.vw_logo)
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val y = h * 0.78f; val bump = h * 0.5f; val cx = w / 2
        val bw = minOf(w * 0.14f, 150f * resources.displayMetrics.density)
        val path = Path(); path.moveTo(0f, y); path.lineTo(cx - bw, y)
        path.cubicTo(cx - bw * 0.5f, y, cx - bw * 0.5f, y - bump, cx, y - bump)
        path.cubicTo(cx + bw * 0.5f, y - bump, cx + bw * 0.5f, y, cx + bw, y); path.lineTo(w, y)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        p.shader = LinearGradient(0f, 0f, w, 0f, intArrayOf(Color.TRANSPARENT, accent, accent, Color.TRANSPARENT), floatArrayOf(0f, .2f, .8f, 1f), Shader.TileMode.CLAMP)
        p.strokeWidth = h * 0.16f; p.alpha = 70; c.drawPath(path, p)
        p.strokeWidth = h * 0.05f; p.alpha = 255; c.drawPath(path, p); p.shader = null
        val s = h * 0.62f; p.style = Paint.Style.FILL; p.alpha = 255
        c.drawBitmap(logo, null, RectF(cx - s / 2, y - bump - s * 0.05f, cx + s / 2, y - bump - s * 0.05f + s), p)
    }
}

/** Contenedor cuadrado: toma el menor de ancho/alto disponibles. */
class SquareBox(ctx: Context) : FrameLayout(ctx) {
    override fun onMeasure(w: Int, h: Int) {
        val s = minOf(MeasureSpec.getSize(w), MeasureSpec.getSize(h))
        super.onMeasure(MeasureSpec.makeMeasureSpec(s, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(s, MeasureSpec.EXACTLY))
    }
}

class MainActivity : Activity() {
    private var night = false
    private var drawerOpen = false
    private var lastStatus = ""
    private val accent get() = if (night) Color.parseColor("#4A9EFF") else Color.parseColor("#1E7BFF")
    private val gray get() = if (night) Color.parseColor("#9AA6BA") else Color.parseColor("#5B6B84")
    private val fg get() = if (night) Color.WHITE else Color.parseColor("#0F1B2D")
    private lateinit var tPos: TextView
    private lateinit var tDur: TextView
    private lateinit var statusRow: LinearLayout
    private lateinit var main: View
    private lateinit var drawer: View
    private lateinit var car: ImageView
    private lateinit var bottomRow: LinearLayout
    private lateinit var tTitle: TextView
    private lateinit var tSub: TextView
    private lateinit var art: ImageView
    private lateinit var playIcon: IconView
    private lateinit var bar: ProgressBar
    private lateinit var tHello: TextView
    private lateinit var tName: TextView
    private var ctrl: MediaController? = null
    private lateinit var carLit: ImageView
    private var lux = -1f
    private var litNow = false
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeak = false
    private var lastSpoken = 0L
    private var player: MediaPlayer? = null
    private var lastIdx = -1
    private lateinit var playerView: View
    private var playerOpen = false
    private var mediaAccess = true
    private lateinit var pTitle: TextView
    private lateinit var pArtist: TextView
    private lateinit var pAlbum: TextView
    private lateinit var pPos: TextView
    private lateinit var pDur: TextView
    private lateinit var pArt: ImageView
    private lateinit var pSeek: SeekView
    private lateinit var pPlay: IconView
    private lateinit var pShuffle: View
    private lateinit var pRepeat: View
    private lateinit var pHeart: View
    private lateinit var statusRow2: LinearLayout
    private lateinit var wxBox: LinearLayout
    private lateinit var wxIconV: IconView
    private lateinit var wxTemp: TextView
    private lateinit var wxCity: TextView
    private var wxText = ""
    private var wxKind = IconView.SUN
    private var lastWx = 0L
    private var shuffleAct: PlaybackState.CustomAction? = null
    private var repeatAct: PlaybackState.CustomAction? = null
    private var likeAct: PlaybackState.CustomAction? = null
    private val bHist = java.util.LinkedList<Pair<Long, Int>>()
    private var brightNight: Boolean? = null
    private var curBright = -1
    private var splashLayer: SplashLayer? = null
    private val splashTimeout = Runnable { endSplash() }
    private var splashActive = false
    private var lastSplash = 0L
    private var resumed = false
    private lateinit var assistLayer: FrameLayout
    private lateinit var orbBig: OrbView
    private lateinit var micBig: IconView
    private lateinit var tAssist: TextView
    private lateinit var tHeard: TextView
    private var recognizer: SpeechRecognizer? = null
    private val hideRunnable = Runnable { closeAssistant() }
    private val rawIds by lazy { (1..20).map { resources.getIdentifier("msg$it", "raw", packageName) }.filter { it != 0 } }
    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable { override fun run() { updateMedia(); updatePlayer(); updateBrightness(); updateLights(); refreshStatus(); handler.postDelayed(this, 1000) } }
    private val prefs by lazy { getSharedPreferences("vento", MODE_PRIVATE) }
    private val apps by lazy { loadApps() }
    private val defaults = listOf("com.whatsapp", "com.spotify.music", "com.google.android.projection.gearhead", "@bt", "@radio", "@apps")
    private val names = listOf("WhatsApp", "Spotify", "Android Auto", "Bluetooth", "Radio FM", "Apps")

    class AppItem(val label: String, val icon: Drawable, val pkg: String)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun glass(r: Int = 22) = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
        if (night) intArrayOf(Color.parseColor("#26FFFFFF"), Color.parseColor("#0DFFFFFF"))
        else intArrayOf(Color.parseColor("#F7FFFFFF"), Color.parseColor("#DDEEF4FF"))).apply {
        cornerRadius = dp(r).toFloat(); setStroke(dp(1), Color.parseColor(if (night) "#664A9EFF" else "#66A9C2E8"))
    }
    private fun oval(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
    private fun ring(fill: Int, stroke: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(fill); setStroke(dp(2), stroke)
    }
    private fun tv(s: String, size: Float, color: Int = fg, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun clipRound(v: View, r: Int) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: Outline) { o.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat()) }
        }
        v.clipToOutline = true
    }
    private fun launch(pkg: String) { packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        night = lightsWanted()
        buildUi()
        maybeSplash()
        initVoice()
    }

    private fun buildUi() {
        lastStatus = ""
        val root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                if (night) intArrayOf(Color.parseColor("#010308"), Color.parseColor("#040A16"))
                else intArrayOf(Color.parseColor("#F6F9FF"), Color.parseColor("#E4ECF8")))
        }
        main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(topBar(), lp(-1, dp(60)))
            addView(middle(), lp(-1, 0, 1f))
            bottomRow = LinearLayout(this@MainActivity).apply { setPadding(dp(20), dp(4), dp(20), dp(14)) }
            refreshBottom()
            addView(bottomRow, lp(-1, dp(104)))
        }
        drawer = ScrollView(this).apply { setPadding(dp(20), dp(16), dp(20), dp(16)); addView(grid(apps, 6, dp(112))) }
        root.addView(main); root.addView(drawer); playerView = buildPlayer(); root.addView(playerView); root.addView(assistantLayer())
        setContentView(root)
        val wasPlayer = playerOpen; show(!drawerOpen); if (wasPlayer) showPlayer(); updateGreeting(); updateMedia(); refreshStatus()
    }

    override fun onResume() {
        super.onResume(); resumed = true; updateGreeting(); handler.post(poll)
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sm.getDefaultSensor(Sensor.TYPE_LIGHT)?.let { sm.registerListener(sensorL, it, SensorManager.SENSOR_DELAY_NORMAL) }
    }
    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(wakeReceiver) } catch (e: Exception) { }
        tts?.shutdown(); player?.release(); recognizer?.destroy()
    }
    override fun onPause() {
        super.onPause(); resumed = false; handler.removeCallbacks(poll); closeAssistant()
        (getSystemService(SENSOR_SERVICE) as SensorManager).unregisterListener(sensorL)
    }
    override fun onBackPressed() { show(true) }
    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); show(true) }
    private fun show(h: Boolean) {
        drawerOpen = !h; playerOpen = false
        main.visibility = if (h) View.VISIBLE else View.GONE
        drawer.visibility = if (h) View.GONE else View.VISIBLE
        if (::playerView.isInitialized) playerView.visibility = View.GONE
    }

    // ---------- barra superior ----------
    private fun topBar() = FrameLayout(this).apply {
        setPadding(dp(24), 0, dp(24), 0)
        addView(LinearLayout(this@MainActivity).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(TextClock(this@MainActivity).apply {
                format12Hour = "HH:mm"; format24Hour = "HH:mm"; setTextColor(fg); textSize = 32f; typeface = Typeface.DEFAULT_BOLD
            })
            addView(View(this@MainActivity).apply { setBackgroundColor(Color.parseColor(if (night) "#44FFFFFF" else "#33000000")) },
                lp(dp(1), dp(26)).apply { setMargins(dp(14), 0, dp(14), 0) })
            addView(TextClock(this@MainActivity).apply {
                format12Hour = "EEE, d 'de' MMM"; format24Hour = "EEE, d 'de' MMM"; setTextColor(gray); textSize = 16f
            })
        }, FrameLayout.LayoutParams(-2, -1, Gravity.START))
        addView(tv("VW", 15f, fg, true).apply {
            gravity = Gravity.CENTER; background = ring(Color.TRANSPARENT, fg)
            setOnClickListener {
                val v = !prefs.getBoolean("voice", true); prefs.edit().putBoolean("voice", v).apply()
                Toast.makeText(this@MainActivity, if (v) "Mensaje de bienvenida activado" else "Mensaje de bienvenida desactivado", Toast.LENGTH_SHORT).show()
            }
            setOnLongClickListener { voiceMenu(); true }
        }, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))
        statusRow = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
        addView(statusRow, FrameLayout.LayoutParams(-2, -1, Gravity.END))
    }

    private fun refreshStatus() {
        var wifi = false; var cell = false; var bt = false
        try {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            wifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            cell = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        } catch (e: Exception) { }
        try { bt = BluetoothAdapter.getDefaultAdapter()?.isEnabled == true } catch (e: Exception) { }
        val key = "$wifi$cell$bt$night"
        if (key == lastStatus) return
        lastStatus = key
        for (row in listOf(statusRow, statusRow2)) {
            row.removeAllViews()
            for ((on, k) in listOf(wifi to IconView.WIFI, bt to IconView.BT, cell to IconView.SIGNAL))
                if (on) row.addView(IconView(this, k, fg), lp(dp(26), dp(26)).apply { setMargins(dp(10), 0, 0, 0) })
        }
    }

    // ---------- zona central ----------
    private fun middle() = LinearLayout(this).apply {
        setPadding(dp(24), dp(4), dp(24), dp(8))
        addView(musicCard(), lp(0, -1, 1.9f).apply { rightMargin = dp(14) })
        addView(carArea(), lp(0, -1, 3.4f))
    }

    private fun musicCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = glass(22); setPadding(dp(18), dp(14), dp(18), dp(14))
            setOnClickListener { if (!mediaAccess) openNotifSettings() else showPlayer() }
        }
        art = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#6A3DE8"), Color.parseColor("#1E6BFF"))).apply { cornerRadius = dp(18).toFloat() }
        }
        clipRound(art, 18)
        val sq = SquareBox(this).apply { addView(art, FrameLayout.LayoutParams(-1, -1)) }
        card.addView(FrameLayout(this).apply { addView(sq, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER)) }, lp(-1, 0, 1f))
        tTitle = tv("Mi música", 28f, fg, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER }
        tSub = tv("Reproduciendo", 18f, gray).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER }
        card.addView(tTitle, lp(-1, -2).apply { topMargin = dp(10) }); card.addView(tSub, lp(-1, -2))
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000; progress = 0
            progressTintList = ColorStateList.valueOf(accent)
            progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor(if (night) "#44FFFFFF" else "#33000000"))
        }
        tPos = tv("0:00", 13f, gray); tDur = tv("0:00", 13f, gray)
        card.addView(bar, lp(-1, dp(8)).apply { topMargin = dp(12) })
        card.addView(LinearLayout(this).apply { addView(tPos, lp(0, -2, 1f)); addView(tDur) }, lp(-1, -2).apply { topMargin = dp(2) })
        playIcon = IconView(this, IconView.PLAY, fg)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        fun btn(ic: IconView, size: Int, ringIt: Boolean, f: () -> Unit) = FrameLayout(this).apply {
            background = if (ringIt) ring(Color.TRANSPARENT, accent) else oval(if (night) Color.parseColor("#1EFFFFFF") else Color.parseColor("#16000000"))
            addView(ic, FrameLayout.LayoutParams(dp(size * 4 / 10), dp(size * 4 / 10), Gravity.CENTER)); setOnClickListener { f() }
        }
        row.addView(btn(IconView(this, IconView.PREV, fg), 68, false) { ctrl?.transportControls?.skipToPrevious() ?: key(KeyEvent.KEYCODE_MEDIA_PREVIOUS) },
            lp(dp(68), dp(68)).apply { setMargins(dp(14), 0, dp(14), 0) })
        row.addView(btn(playIcon, 92, true) { playPause() }, lp(dp(92), dp(92)).apply { setMargins(dp(14), 0, dp(14), 0) })
        row.addView(btn(IconView(this, IconView.NEXT, fg), 68, false) { ctrl?.transportControls?.skipToNext() ?: key(KeyEvent.KEYCODE_MEDIA_NEXT) },
            lp(dp(68), dp(68)).apply { setMargins(dp(14), 0, dp(14), 0) })
        card.addView(row, lp(-1, -2).apply { topMargin = dp(10) })
        return card
    }

    private fun carArea(): View {
        val f = FrameLayout(this)
        car = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(0, dp(46), 0, 0) }
        val saved = File(filesDir, "car.png")
        val bmp = if (saved.exists()) decode(saved) else null
        if (bmp != null) car.setImageBitmap(bmp) else car.setImageResource(if (night) R.drawable.car_night else R.drawable.car_day)
        f.addView(car)
        tHello = tv("", 20f, fg)
        tName = tv("", 34f, fg, true).apply { setTypeface(Typeface.DEFAULT_BOLD, Typeface.ITALIC) }
        val g = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(IconView(this@MainActivity, IconView.WAVE, accent), lp(dp(34), dp(34)).apply { rightMargin = dp(12) })
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.END; addView(tHello); addView(tName)
            })
            setOnLongClickListener { askName(); true }
        }
        f.addView(g, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(6), dp(8), 0) })
        f.setOnLongClickListener { pickPhoto(); true }
        f.setOnClickListener { cycleLights() }
        return f
    }

    private fun updateGreeting() {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        tHello.text = if (h < 12) "¡Buenos días," else if (h < 19) "¡Buenas tardes," else "¡Buenas noches,"
        tName.text = (prefs.getString("name", "José Luis") ?: "José Luis") + "!"
    }

    private fun askName() {
        val et = EditText(this).apply { setText(prefs.getString("name", "José Luis")) }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Tu nombre").setView(et)
            .setPositiveButton("Guardar") { _, _ -> prefs.edit().putString("name", et.text.toString().trim()).apply(); updateGreeting() }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun pickPhoto() {
        try { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1) }
        catch (e: Exception) { Toast.makeText(this, "No hay galería o explorador de archivos", Toast.LENGTH_LONG).show() }
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r == 2 && c == RESULT_OK) { d?.data?.let { saveWelcomeAudio(it) }; return }
        if (r != 1 || c != RESULT_OK) return
        val uri = d?.data ?: return
        try {
            val f = File(filesDir, "car.png")
            contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            decode(f)?.let { car.setImageBitmap(it) }
        } catch (e: Exception) { Toast.makeText(this, "No se pudo cargar la imagen", Toast.LENGTH_LONG).show() }
    }

    private fun decode(f: File): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > 2000) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    // ---------- luces del auto ----------
    private val sensorL = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) { lux = e.values[0] }
        override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    }

    private fun lightsWanted(): Boolean = when (prefs.getInt("lights", 0)) {
        1 -> true
        2 -> false
        3 -> java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY).let { it >= 19 || it < 6 }
        else -> brightVerdict() ?: run {
            val ui = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            if (ui) true else if (lux < 0f) false else if (lux <= 15f) true else if (lux > 40f) false else night
        }
    }

    private fun updateLights() {
        if (splashActive) return
        val on = lightsWanted()
        if (on != night) { night = on; if (::assistLayer.isInitialized) closeAssistant(); buildUi() }
    }

    private fun cycleLights() {
        val m = (prefs.getInt("lights", 0) + 1) % 4
        prefs.edit().putInt("lights", m).apply()
        Toast.makeText(this, listOf("Modo: automático (brillo de la radio, sensor o modo nocturno)", "Modo: siempre noche (luces encendidas)",
            "Modo: siempre día", "Modo: por horario (noche 7 pm a 6 am)")[m], Toast.LENGTH_SHORT).show()
        updateLights()
    }

    // ---------- voz de bienvenida ----------
    private val wakeReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (resumed && SystemClock.elapsedRealtime() - lastSplash > 30000) maybeSplash()
            speakWelcome(false)
        }
    }

    private fun initVoice() {
        tts = TextToSpeech(this) { st ->
            val t = tts
            if (st == TextToSpeech.SUCCESS && t != null) {
                if (t.setLanguage(Locale("es", "MX")) < TextToSpeech.LANG_AVAILABLE) t.setLanguage(Locale("es"))
                applyVoicePrefs()
                ttsReady = true
                if (pendingSpeak) { pendingSpeak = false; speakWelcome(false) }
            }
        }
        registerReceiver(wakeReceiver, IntentFilter(Intent.ACTION_SCREEN_ON))
        speakWelcome(false)
    }

    private fun speakWelcome(force: Boolean) {
        if (!force && !prefs.getBoolean("voice", true)) return
        val now = SystemClock.elapsedRealtime()
        if (!force && lastSpoken != 0L && now - lastSpoken < 30000) return
        if (File(filesDir, "welcome.snd").exists() || rawIds.isNotEmpty()) {
            lastSpoken = now
            handler.postDelayed({ playWelcomeAudio(force) }, if (force) 0L else if (splashActive) 5900L else 2500L)
            return
        }
        if (!ttsReady) { pendingSpeak = true; return }
        lastSpoken = now
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val hi = if (h < 12) "Buenos días" else if (h < 19) "Buenas tardes" else "Buenas noches"
        val name = prefs.getString("name", "José Luis")
        val msgs = listOf(
            "Recuerda abrochar tu cinturón y respetar los límites de velocidad.",
            "Maneja con calma, guarda la distancia con el auto de enfrente y no uses el celular mientras conduces.",
            "Revisa tus espejos antes de arrancar. Llegar con bien es lo más importante.",
            "Antes de arrancar, confirma que todos los pasajeros traigan el cinturón puesto.",
            "Si vas a tomar, no manejes. Cuida tu vida y la de los demás."
        )
        val text = "$hi, $name. Bienvenido a bordo. ${msgs.random()}"
        handler.postDelayed({ tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "welcome") }, if (force) 0L else if (splashActive) 5900L else 2500L)
    }

    // ---------- deteccion por brillo de la radio ----------
    private fun readBrightness(): Int =
        try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, -1) } catch (e: Exception) { -1 }

    /** Detecta bajadas o subidas bruscas del brillo (lo que hace la radio al prender las luces) y aprende los dos niveles. */
    private fun updateBrightness() {
        val b = readBrightness(); curBright = b
        if (b < 0) return
        val now = SystemClock.elapsedRealtime()
        bHist.add(now to b)
        while (bHist.size > 1 && now - bHist.peekFirst()!!.first > 4000) bHist.removeFirst()
        val ref = bHist.peekFirst()!!.second
        if (!prefs.getBoolean("bCal", false)) {
            if (b <= ref * 0.65f && ref - b >= 15) { brightNight = true; prefs.edit().putInt("bDay", ref).putInt("bNight", b).apply() }
            else if (b >= ref * 1.45f && b - ref >= 15) { brightNight = false; prefs.edit().putInt("bDay", b).putInt("bNight", ref).apply() }
        }
    }

    private fun brightVerdict(): Boolean? {
        if (curBright < 0) return null
        val d = prefs.getInt("bDay", -1); val n = prefs.getInt("bNight", -1)
        if (d >= 0 && n >= 0 && d - n >= 10) {
            val lo = n + (d - n) * 0.4f; val hi = n + (d - n) * 0.6f
            return if (curBright <= lo) true else if (curBright >= hi) false else night
        }
        return brightNight
    }

    private fun settingsSnapshot(): Map<String, String> {
        val m = HashMap<String, String>()
        for (t in listOf("system", "secure", "global")) try {
            contentResolver.query(Uri.parse("content://settings/$t"), arrayOf("name", "value"), null, null, null)?.use { c ->
                while (c.moveToNext()) m["$t/${c.getString(0)}"] = c.getString(1) ?: ""
            }
        } catch (e: Exception) { }
        return m
    }

    private fun saveBrightness(day: Boolean) {
        val b = readBrightness()
        if (b < 0) { Toast.makeText(this, "No pude leer el brillo", Toast.LENGTH_LONG).show(); return }
        prefs.edit().putInt(if (day) "bDay" else "bNight", b).putBoolean("bCal", true).apply()
        Toast.makeText(this, "Brillo de ${if (day) "día" else "noche"} guardado: $b", Toast.LENGTH_LONG).show()
    }

    private fun lightsDiagnostic() {
        val base = settingsSnapshot(); val seen = LinkedHashMap<String, String>()
        val tvd = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; setPadding(dp(20), dp(10), dp(20), dp(10)) }
        val tick = object : Runnable {
            override fun run() {
                for ((k, v) in settingsSnapshot()) { val o = base[k]; if (o != null && o != v && !k.contains("time", true)) seen[k] = "$o → $v" }
                val ui = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
                val mode = listOf("Automático", "Siempre noche", "Siempre día", "Por horario")[prefs.getInt("lights", 0)]
                tvd.text = "Brillo de la radio (0-255): ${readBrightness()}\n" +
                    "Guardado → día: ${prefs.getInt("bDay", -1)} | noche: ${prefs.getInt("bNight", -1)}\n" +
                    "Sensor de luz: ${if (lux >= 0f) lux.toString() else "sin dato"}\n" +
                    "Modo nocturno de Android: ${if (ui) "sí" else "no"}\n" +
                    "Modo elegido: $mode\nLa app decide ahora: ${if (night) "NOCHE" else "DÍA"}\n\n" +
                    "Ajustes que cambiaron con esta pantalla abierta:\n" +
                    (if (seen.isEmpty()) "(ninguno todavía: prende y apaga las luces del auto)" else seen.entries.take(14).joinToString("\n") { "${it.key}: ${it.value}" })
                handler.postDelayed(this, 2000)
            }
        }
        val d = dlg().setTitle("Diagnóstico de luces").setView(ScrollView(this).apply { addView(tvd) })
            .setPositiveButton("Guardar como DÍA") { _, _ -> saveBrightness(true) }
            .setNegativeButton("Guardar como NOCHE") { _, _ -> saveBrightness(false) }
            .setNeutralButton("Cerrar", null).create()
        d.setOnDismissListener { handler.removeCallbacks(tick) }
        d.show(); tick.run()
    }

    // ---------- reproductor a pantalla completa ----------
    private fun openNotifSettings() {
        try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        catch (e: Exception) { Toast.makeText(this, "Ajustes > Acceso a notificaciones", Toast.LENGTH_LONG).show() }
    }

    private fun showPlayer() {
        playerOpen = true; drawerOpen = false
        main.visibility = View.GONE; drawer.visibility = View.GONE; playerView.visibility = View.VISIBLE
        applyWeather(); fetchWeather(); updatePlayer()
    }

    private fun buildPlayer(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                if (night) intArrayOf(Color.parseColor("#010308"), Color.parseColor("#040A16"))
                else intArrayOf(Color.parseColor("#F6F9FF"), Color.parseColor("#E4ECF8")))
        }
        root.addView(playerTop(), lp(-1, dp(64)))
        val mid = LinearLayout(this).apply { setPadding(0, dp(6), dp(20), 0) }
        mid.addView(playerSide(), lp(dp(92), -1).apply { setMargins(0, 0, dp(16), dp(6)) })
        mid.addView(playerContent(), lp(0, -1, 1f))
        root.addView(mid, lp(-1, 0, 1f))
        return root
    }

    private fun vdiv() = View(this).apply { setBackgroundColor(Color.parseColor(if (night) "#44FFFFFF" else "#33000000")) }

    private fun playerTop(): View {
        val f = FrameLayout(this); f.setPadding(dp(20), 0, dp(20), 0)
        val left = LinearLayout(this); left.gravity = Gravity.CENTER_VERTICAL
        left.addView(ImageView(this).apply { setImageResource(R.drawable.vw_logo) }, lp(dp(46), dp(46)).apply { rightMargin = dp(12) })
        val names = LinearLayout(this); names.orientation = LinearLayout.VERTICAL
        names.addView(tv("VENTO", 24f, fg, true).apply { setTypeface(Typeface.DEFAULT_BOLD, Typeface.ITALIC) })
        names.addView(tv("LAUNCHER", 11f, gray).apply { letterSpacing = 0.3f })
        left.addView(names); f.addView(left, FrameLayout.LayoutParams(-2, -1, Gravity.START))
        val right = LinearLayout(this); right.gravity = Gravity.CENTER_VERTICAL
        wxBox = LinearLayout(this); wxBox.gravity = Gravity.CENTER_VERTICAL; wxBox.visibility = View.GONE
        wxIconV = IconView(this, IconView.SUN, Color.parseColor("#FFC21F")); wxTemp = tv("", 22f, fg, true); wxCity = tv("", 12f, gray)
        wxBox.addView(wxIconV, lp(dp(32), dp(32)).apply { rightMargin = dp(8) })
        val wt = LinearLayout(this); wt.orientation = LinearLayout.VERTICAL; wt.addView(wxTemp); wt.addView(wxCity); wxBox.addView(wt)
        right.addView(wxBox); right.addView(vdiv(), lp(dp(1), dp(36)).apply { setMargins(dp(14), 0, dp(14), 0) })
        val clock = LinearLayout(this); clock.orientation = LinearLayout.VERTICAL
        clock.addView(TextClock(this).apply { format12Hour = "hh:mm a"; format24Hour = "hh:mm a"; setTextColor(fg); textSize = 24f; typeface = Typeface.DEFAULT_BOLD })
        clock.addView(TextClock(this).apply { format12Hour = "EEE. dd MMM. yyyy"; format24Hour = "EEE. dd MMM. yyyy"; setTextColor(gray); textSize = 12f })
        right.addView(clock); right.addView(vdiv(), lp(dp(1), dp(36)).apply { setMargins(dp(14), 0, dp(10), 0) })
        statusRow2 = LinearLayout(this); statusRow2.gravity = Gravity.CENTER_VERTICAL; right.addView(statusRow2)
        f.addView(right, FrameLayout.LayoutParams(-2, -1, Gravity.END))
        f.addView(View(this).apply { background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.TRANSPARENT, accent, Color.TRANSPARENT)) },
            FrameLayout.LayoutParams(-1, dp(2), Gravity.BOTTOM))
        return f
    }

    private fun navApp() {
        val pk = listOf("com.google.android.apps.maps", "com.waze").firstOrNull { x -> apps.any { it.pkg == x } }
        if (pk != null) launch(pk) else Toast.makeText(this, "Instala Google Maps o Waze", Toast.LENGTH_LONG).show()
    }

    private fun phoneApp() {
        try { startActivity(Intent(Intent.ACTION_DIAL)) } catch (e: Exception) { Toast.makeText(this, "No encontré la app de llamadas", Toast.LENGTH_LONG).show() }
    }

    private fun playerSide(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = glass(30); setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val items = listOf<Pair<Int, () -> Unit>>(IconView.MUSIC to { }, IconView.NAVI to { navApp() }, IconView.PHONE to { phoneApp() },
            IconView.CARI to { show(true) }, IconView.APPS to { show(false) })
        items.forEachIndexed { i, (kind, act) ->
            val b = FrameLayout(this).apply {
                if (i == 0) background = GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat(); setColor(Color.parseColor(if (night) "#082454" else "#D6E5FF")); setStroke(dp(2), accent)
                }
                addView(IconView(this@MainActivity, kind, if (i == 0 && !night) accent else fg), FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
                setOnClickListener { act() }
            }
            col.addView(b, lp(dp(66), dp(66)).apply { setMargins(0, dp(6), 0, dp(6)) })
        }
        return col
    }

    private fun sendAct(a: PlaybackState.CustomAction?) { if (a != null) ctrl?.transportControls?.sendCustomAction(a, null) }

    private fun seekToFraction(f: Float) {
        val c = ctrl ?: return
        val dur = c.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        if (dur > 0) c.transportControls.seekTo((dur * f).toLong())
    }

    private fun pcell(v: View, sz: Int, ringIt: Boolean, onClick: () -> Unit): View {
        val inner = FrameLayout(this)
        if (ringIt) inner.background = ring(Color.TRANSPARENT, accent)
        val g = if (ringIt) dp(sz * 4 / 10) else dp(sz)
        inner.addView(v, FrameLayout.LayoutParams(g, g, Gravity.CENTER)); inner.setOnClickListener { onClick() }
        val box = FrameLayout(this); val bs = dp(if (ringIt) sz else sz + 24)
        box.addView(inner, FrameLayout.LayoutParams(bs, bs, Gravity.CENTER)); return box
    }

    private fun playerContent(): View {
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        val row1 = LinearLayout(this); row1.gravity = Gravity.CENTER_VERTICAL
        pArt = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#6A3DE8"), Color.parseColor("#1E6BFF"))).apply { cornerRadius = dp(28).toFloat() }
        }
        clipRound(pArt, 28)
        val sq = SquareBox(this).apply { addView(pArt, FrameLayout.LayoutParams(-1, -1)) }
        row1.addView(FrameLayout(this).apply { addView(sq, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER)) },
            lp(0, -1, 1f).apply { setMargins(0, dp(8), dp(28), dp(8)) })
        val info = LinearLayout(this); info.orientation = LinearLayout.VERTICAL; info.gravity = Gravity.CENTER_VERTICAL
        info.addView(View(this).apply { setBackgroundColor(accent) }, lp(dp(64), dp(5)).apply { bottomMargin = dp(12) })
        pTitle = tv("Mi música", 40f, fg, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        pHeart = pcell(IconView(this, IconView.HEART, fg), 36, false) { sendAct(likeAct) }; pHeart.visibility = View.INVISIBLE
        val titleRow = LinearLayout(this); titleRow.gravity = Gravity.CENTER_VERTICAL
        titleRow.addView(pTitle, lp(0, -2, 1f)); titleRow.addView(pHeart, lp(dp(60), dp(60))); info.addView(titleRow, lp(-1, -2))
        pArtist = tv("Reproduciendo", 28f, gray).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        pAlbum = tv("", 19f, gray).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        info.addView(pArtist, lp(-1, -2).apply { topMargin = dp(2) }); info.addView(pAlbum, lp(-1, -2))
        pSeek = SeekView(this).apply {
            accent = this@MainActivity.accent; track = Color.parseColor(if (night) "#33FFFFFF" else "#33000000"); onSeek = { f -> seekToFraction(f) }
        }
        info.addView(pSeek, lp(-1, dp(44)).apply { topMargin = dp(22) })
        pPos = tv("0:00", 20f, gray); pDur = tv("0:00", 20f, gray)
        val times = LinearLayout(this); times.addView(pPos, lp(0, -2, 1f)); times.addView(pDur); info.addView(times, lp(-1, -2))
        pPlay = IconView(this, IconView.PLAY, fg)
        pShuffle = pcell(IconView(this, IconView.SHUFFLE, gray), 36, false) { sendAct(shuffleAct) }; pShuffle.visibility = View.INVISIBLE
        pRepeat = pcell(IconView(this, IconView.REPEAT, gray), 36, false) { sendAct(repeatAct) }; pRepeat.visibility = View.INVISIBLE
        val prev = pcell(IconView(this, IconView.PREV, fg), 48, false) { ctrl?.transportControls?.skipToPrevious() ?: key(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }
        val play = pcell(pPlay, 120, true) { playPause() }
        val next = pcell(IconView(this, IconView.NEXT, fg), 48, false) { ctrl?.transportControls?.skipToNext() ?: key(KeyEvent.KEYCODE_MEDIA_NEXT) }
        val controls = LinearLayout(this); controls.gravity = Gravity.CENTER
        for (v in listOf(pShuffle, prev, play, next, pRepeat)) controls.addView(v, lp(0, dp(128), 1f))
        info.addView(controls, lp(-1, dp(128)).apply { topMargin = dp(6) })
        row1.addView(info, lp(0, -1, 1.1f)); col.addView(row1, lp(-1, 0, 1f))
        col.addView(BaseLineView(this, accent), lp(-1, dp(46)))
        return col
    }

    private fun updatePlayer() {
        if (!::playerView.isInitialized || playerView.visibility != View.VISIBLE) return
        val c = ctrl; val md = c?.metadata
        if (c == null || md == null) {
            pTitle.text = if (mediaAccess) "Mi música" else "Activar música en pantalla"
            pArtist.text = if (mediaAccess) "Abre Spotify o YouTube Music" else "Vuelve al inicio, toca la tarjeta y permite el acceso"
            pAlbum.text = ""; pArt.setImageDrawable(null); pPlay.kind = IconView.PLAY; pPlay.invalidate()
            if (!pSeek.dragging) { pSeek.progress = 0f; pSeek.invalidate() }
            pPos.text = "0:00"; pDur.text = "0:00"
            pShuffle.visibility = View.INVISIBLE; pRepeat.visibility = View.INVISIBLE; pHeart.visibility = View.INVISIBLE
            return
        }
        pTitle.text = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Sin título"
        pArtist.text = md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        pAlbum.text = md.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        val bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART) ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (bmp != null) pArt.setImageBitmap(bmp) else pArt.setImageDrawable(null)
        val ps = c.playbackState; val playing = ps?.state == PlaybackState.STATE_PLAYING
        pPlay.kind = if (playing) IconView.PAUSE else IconView.PLAY; pPlay.invalidate()
        val dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION)
        if (ps != null && dur > 0) {
            var pos = ps.position
            if (playing) pos += ((SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * ps.playbackSpeed).toLong()
            if (!pSeek.dragging) { pSeek.progress = (pos.toFloat() / dur).coerceIn(0f, 1f); pSeek.invalidate() }
            pPos.text = fmt(pos.coerceIn(0L, dur)); pDur.text = fmt(dur)
        } else { if (!pSeek.dragging) { pSeek.progress = 0f; pSeek.invalidate() }; pPos.text = "0:00"; pDur.text = "0:00" }
        val acts = ps?.customActions ?: emptyList<PlaybackState.CustomAction>()
        fun find(vararg k: String) = acts.firstOrNull { a -> k.any { (a.action + " " + a.name).contains(it, true) } }
        shuffleAct = find("shuffle", "aleator"); repeatAct = find("repeat", "repet"); likeAct = find("like", "heart", "favorit", "save", "add_to", "me gusta")
        pShuffle.visibility = if (shuffleAct != null) View.VISIBLE else View.INVISIBLE
        pRepeat.visibility = if (repeatAct != null) View.VISIBLE else View.INVISIBLE
        pHeart.visibility = if (likeAct != null) View.VISIBLE else View.INVISIBLE
    }

    private fun applyWeather() {
        if (!::wxBox.isInitialized) return
        if (wxText.isEmpty()) { wxBox.visibility = View.GONE; return }
        wxBox.visibility = View.VISIBLE; wxTemp.text = wxText; wxCity.text = prefs.getString("wxCity", "Culiacán, Sin.")
        wxIconV.kind = wxKind; wxIconV.invalidate()
    }

    private fun fetchWeather() {
        if (wxText.isNotEmpty() && SystemClock.elapsedRealtime() - lastWx < 1800000L) return
        lastWx = SystemClock.elapsedRealtime()
        val lat = prefs.getString("wxLat", "24.8091"); val lon = prefs.getString("wxLon", "-107.3940")
        Thread {
            try {
                val u = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code&timezone=auto")
                val cn = u.openConnection() as HttpURLConnection; cn.connectTimeout = 6000; cn.readTimeout = 6000
                val j = org.json.JSONObject(cn.inputStream.bufferedReader().readText()).getJSONObject("current")
                val temp = Math.round(j.getDouble("temperature_2m")).toInt(); val code = j.getInt("weather_code")
                handler.post { wxText = "$temp°C"; wxKind = if (code <= 1) IconView.SUN else IconView.CLOUD; applyWeather() }
            } catch (e: Exception) { lastWx = 0L }
        }.start()
    }

    // ---------- animacion de inicio ----------
    private fun maybeSplash() { if (prefs.getBoolean("splash", true)) playSplash() }

    private fun playSplash() {
        if (splashActive) return
        splashActive = true; lastSplash = SystemClock.elapsedRealtime()
        val layer = SplashLayer(this); splashLayer = layer
        findViewById<ViewGroup>(android.R.id.content).addView(layer, ViewGroup.LayoutParams(-1, -1))
        layer.setOnClickListener { endSplash() }
        layer.video.setOnPreparedListener { layer.video.start() }
        layer.video.setOnCompletionListener { endSplash() }
        layer.video.setOnErrorListener { _, _, _ -> endSplash(); true }
        layer.video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.vento_intro}"))
        handler.postDelayed(splashTimeout, 7500L)
    }

    private fun endSplash() {
        handler.removeCallbacks(splashTimeout)
        val l = splashLayer ?: return
        splashLayer = null
        try { l.video.stopPlayback() } catch (e: Exception) { }
        l.animate().alpha(0f).setDuration(350).withEndAction {
            (l.parent as? ViewGroup)?.removeView(l); splashActive = false
        }.start()
    }

    // ---------- menu de voz ----------
    private fun applyVoicePrefs() {
        val t = tts ?: return
        t.setSpeechRate(prefs.getFloat("rate", 1f)); t.setPitch(prefs.getFloat("pitch", 1f))
        val n = prefs.getString("voiceName", null)
        if (n != null) t.voices?.find { it.name == n }?.let { v -> t.setVoice(v) }
    }

    private fun sample() {
        tts?.speak("Hola, así suena esta voz. Bienvenido a bordo.", TextToSpeech.QUEUE_FLUSH, null, "sample")
    }

    private fun openTtsSettings() {
        try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
        catch (e: Exception) { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e2: Exception) { } }
    }

    private fun dlg() = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun voiceMenu() {
        val hasAudio = File(filesDir, "welcome.snd").exists()
        val items = arrayOf("Probar mensaje (uno al azar)", "Elegir mi audio (mp3, m4a, wav...)",
            if (hasAudio) "Quitar mi audio y usar los mensajes de fábrica" else "Elegir voz del sistema (respaldo)", "Velocidad de la voz", "Tono de la voz",
            "Más voces (ajustes del sistema)", "Probar animación y sonido de inicio",
            if (prefs.getBoolean("splash", true)) "Desactivar animación de inicio" else "Activar animación de inicio",
            "Diagnóstico de luces (día/noche)", "Borrar calibración de brillo")
        dlg().setTitle("Mensaje de bienvenida" + if (hasAudio) " (usando tu audio)" else " (mensajes de fábrica)").setItems(items) { _, w ->
            when (w) {
                0 -> speakWelcome(true)
                1 -> try { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("audio/*"), 2) }
                     catch (e: Exception) { Toast.makeText(this, "No hay explorador de archivos en la radio", Toast.LENGTH_LONG).show() }
                2 -> if (hasAudio) { File(filesDir, "welcome.snd").delete(); Toast.makeText(this, "Se usarán los mensajes de fábrica", Toast.LENGTH_SHORT).show() } else voicePicker()
                3 -> pickFloat("Velocidad", arrayOf("Lenta", "Normal", "Rápida"), floatArrayOf(0.8f, 1f, 1.2f), "rate")
                4 -> pickFloat("Tono", arrayOf("Grave", "Normal", "Agudo"), floatArrayOf(0.85f, 1f, 1.15f), "pitch")
                5 -> openTtsSettings()
                6 -> playSplash()
                7 -> prefs.edit().putBoolean("splash", !prefs.getBoolean("splash", true)).apply()
                8 -> lightsDiagnostic()
                else -> { prefs.edit().remove("bDay").remove("bNight").remove("bCal").apply(); brightNight = null
                    Toast.makeText(this, "Calibración de brillo borrada", Toast.LENGTH_SHORT).show() }
            }
        }.show()
    }

    private fun saveWelcomeAudio(uri: android.net.Uri) {
        try {
            val f = File(filesDir, "welcome.snd")
            contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            Toast.makeText(this, "Audio guardado. Suena al encender la radio.", Toast.LENGTH_LONG).show()
            playWelcomeAudio()
        } catch (e: Exception) { Toast.makeText(this, "No se pudo cargar el audio", Toast.LENGTH_LONG).show() }
    }

    private fun playWelcomeAudio(announce: Boolean = false) {
        val custom = File(filesDir, "welcome.snd")
        try {
            player?.release()
            val mp = MediaPlayer()
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            if (custom.exists()) mp.setDataSource(custom.path)
            else {
                if (rawIds.isEmpty()) { mp.release(); return }
                var n = rawIds.indices.random()
                if (rawIds.size > 1) while (n == lastIdx) n = rawIds.indices.random()
                lastIdx = n
                val afd = resources.openRawResourceFd(rawIds[n])
                mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length); afd.close()
                if (announce) Toast.makeText(this, "Mensaje ${n + 1} de ${rawIds.size}", Toast.LENGTH_SHORT).show()
            }
            mp.prepare(); mp.start()
            mp.setOnCompletionListener { it.release(); if (player === it) player = null }
            player = mp
        } catch (e: Exception) {
            Toast.makeText(this, "Ese audio no se pudo reproducir. Prueba con mp3.", Toast.LENGTH_LONG).show()
        }
    }

    private fun pickFloat(title: String, labels: Array<String>, vals: FloatArray, key: String) {
        dlg().setTitle(title).setItems(labels) { _, w ->
            prefs.edit().putFloat(key, vals[w]).apply(); applyVoicePrefs(); sample()
        }.show()
    }

    private fun voicePicker() {
        val vs = (tts?.voices ?: emptySet()).filter { it.locale.language == "es" }.sortedBy { it.name }
        if (vs.isEmpty()) {
            Toast.makeText(this, "Tu radio no ofrece voces en español. Instala Servicios de voz de Google.", Toast.LENGTH_LONG).show()
            openTtsSettings(); return
        }
        val cur = prefs.getString("voiceName", null) ?: tts?.voice?.name
        val labels = vs.mapIndexed { i, v ->
            "Voz ${i + 1} · " + v.locale.displayCountry.ifEmpty { v.locale.displayLanguage } +
                (if (v.isNetworkConnectionRequired) " (necesita internet)" else "")
        }.toTypedArray()
        dlg().setTitle("Elegir voz (toca para escuchar)")
            .setSingleChoiceItems(labels, vs.indexOfFirst { it.name == cur }) { _, w ->
                prefs.edit().putString("voiceName", vs[w].name).apply(); tts?.setVoice(vs[w]); sample()
            }
            .setPositiveButton("Listo", null).show()
    }

    // ---------- asistente ----------
    private fun assistantLayer(): FrameLayout {
        orbBig = OrbView(this)
        micBig = IconView(this, IconView.MIC, fg)
        tAssist = tv("", 24f, fg, true).apply { gravity = Gravity.CENTER }
        tHeard = tv("", 16f, gray).apply { gravity = Gravity.CENTER }
        val orbFrame = FrameLayout(this).apply {
            addView(orbBig, FrameLayout.LayoutParams(-1, -1))
            addView(micBig, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            addView(orbFrame, lp(dp(250), dp(250)))
            addView(tAssist, lp(-1, -2).apply { setMargins(dp(40), dp(8), dp(40), 0) })
            addView(tHeard, lp(-1, -2).apply { setMargins(dp(40), dp(6), dp(40), 0) })
        }
        assistLayer = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor(if (night) "#F2050A14" else "#F2F4F8FF")); visibility = View.GONE
            addView(col, FrameLayout.LayoutParams(-1, -1)); setOnClickListener { closeAssistant() }
        }
        return assistLayer
    }

    private fun setMode(m: Int, text: String) {
        orbBig.mode = m; tAssist.text = text
        micBig.visibility = if (m == 2) View.GONE else View.VISIBLE
    }

    private val recListener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) { orbBig.level = ((v + 2f) / 12f).coerceIn(0f, 1f) }
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(e: Int) { respond("No te escuché bien. Toca el micrófono para intentar de nuevo.") }
        override fun onResults(r: Bundle?) { handle(r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()) }
        override fun onPartialResults(r: Bundle?) {
            tHeard.text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
        }
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    private fun openAssistant() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7); return
        }
        handler.removeCallbacks(hideRunnable)
        assistLayer.visibility = View.VISIBLE; tHeard.text = ""; orbBig.level = 0f
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            respond("Tu radio no tiene reconocimiento de voz. Instala la app de Google."); return
        }
        setMode(1, "ESCUCHANDO...")
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(recListener)
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true))
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 7) {
            if (res.firstOrNull() == PackageManager.PERMISSION_GRANTED) openAssistant()
            else Toast.makeText(this, "Sin permiso de micrófono no puedo escucharte", Toast.LENGTH_LONG).show()
        }
    }

    private fun closeAssistant() {
        handler.removeCallbacks(hideRunnable)
        recognizer?.destroy(); recognizer = null
        tts?.stop()
        assistLayer.visibility = View.GONE
    }

    private fun respond(msg: String, then: (() -> Unit)? = null) {
        setMode(2, msg)
        if (ttsReady && prefs.getBoolean("assistVoice", true)) tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "assist")
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, 2500L + msg.length * 55L)
        if (then != null) handler.postDelayed({ then() }, 900L)
    }

    private fun norm(x: String) =
        java.text.Normalizer.normalize(x.lowercase(), java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    private fun findApp(q: String): AppItem? {
        val n = norm(q).trim(); if (n.isEmpty()) return null
        return apps.find { norm(it.label) == n } ?: apps.find { norm(it.label).startsWith(n) }
            ?: apps.find { norm(it.label).contains(n) }
            ?: apps.find { norm(it.label).length > 2 && n.contains(norm(it.label)) }
    }

    private fun navigateTo(dest: String): Boolean {
        val q = Uri.encode(dest)
        return try {
            if (apps.any { it.pkg == "com.google.android.apps.maps" }) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$q")).setPackage("com.google.android.apps.maps")); true
            } else if (apps.any { it.pkg == "com.waze" }) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://waze.com/ul?q=$q&navigate=yes")).setPackage("com.waze")); true
            } else false
        } catch (e: Exception) { false }
    }

    private fun setLights(m: Int) { prefs.edit().putInt("lights", m).apply(); updateLights() }

    private fun handle(raw: String?) {
        val t = norm(raw ?: "").trim()
        tHeard.text = raw ?: ""
        fun has(vararg w: String) = w.any { t.contains(it) }
        val nav = Regex("^(navega a|navegar a|llevame a|ve a|ir a|como llego a|como llegar a)\\s+(.+)$").find(t)
        val op = Regex("^(abre|abrir|abreme|inicia|ejecuta|lanza|activa|pon)\\s+(.+)$").find(t)
        val name = prefs.getString("name", "José Luis") ?: ""
        when {
            t.isEmpty() -> respond("No te escuché bien. Intenta de nuevo.")
            has("pausa", "pausar", "deten la musica", "para la musica", "silencio") -> {
                ctrl?.transportControls?.pause() ?: key(KeyEvent.KEYCODE_MEDIA_PAUSE); respond("Música en pausa")
            }
            has("siguiente", "proxima", "cambia la cancion") -> {
                ctrl?.transportControls?.skipToNext() ?: key(KeyEvent.KEYCODE_MEDIA_NEXT); respond("Siguiente canción")
            }
            has("anterior", "regresa la cancion") -> {
                ctrl?.transportControls?.skipToPrevious() ?: key(KeyEvent.KEYCODE_MEDIA_PREVIOUS); respond("Canción anterior")
            }
            has("reproduce", "pon musica", "continua", "dale play") -> {
                ctrl?.transportControls?.play() ?: key(KeyEvent.KEYCODE_MEDIA_PLAY); respond("Reproduciendo")
            }
            has("apaga las luces", "luces apagadas") -> { setLights(2); respond("Luces apagadas") }
            has("enciende las luces", "prende las luces", "luces encendidas") -> { setLights(1); respond("Luces encendidas") }
            has("luces automaticas", "luces en automatico") -> { setLights(0); respond("Luces en automático") }
            has("que hora") -> respond("Son las " + SimpleDateFormat("H:mm", Locale("es", "MX")).format(java.util.Date()))
            has("que dia", "que fecha") -> respond("Hoy es " + SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "MX")).format(java.util.Date()))
            nav != null -> {
                val dest = nav.groupValues[2]
                if (navigateTo(dest)) respond("Navegando a $dest") else respond("Necesito Google Maps o Waze instalados")
            }
            op != null -> {
                val target = norm(op.groupValues[2])
                when {
                    target.contains("bluetooth") -> respond("Abriendo Bluetooth") { try { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } catch (e: Exception) { } }
                    target.contains("ajustes") || target.contains("configuracion") -> respond("Abriendo ajustes") { startActivity(Intent(Settings.ACTION_SETTINGS)) }
                    target == "apps" || target.contains("aplicaciones") -> respond("Aquí están tus apps") { show(false) }
                    else -> {
                        val a = if (target == "mapa" || target == "mapas") apps.find { it.pkg == "com.google.android.apps.maps" }
                            else if (target.contains("radio")) resolve("@radio") else findApp(target)
                        if (a != null) respond("Abriendo ${a.label}") { launch(a.pkg) } else respond("No encontré la app ${op.groupValues[2]}")
                    }
                }
            }
            has("hola", "buenas") -> respond("Hola $name, ¿en qué te ayudo?")
            has("gracias") -> respond("Con gusto")
            else -> respond("No entendí. Prueba: abre Waze, pon pausa, navega a el centro, o enciende las luces.")
        }
    }

    // ---------- musica ----------
    private fun key(code: Int) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun playPause() {
        val c = ctrl
        if (c == null) { key(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); return }
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause() else c.transportControls.play()
    }

    private fun updateMedia() {
        try {
            val msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(this, MediaListener::class.java))
            mediaAccess = true
            ctrl = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
            val md = ctrl?.metadata
            if (md == null) {
                tTitle.text = "Mi música"; tSub.text = "Abre Spotify o YouTube Music"
                art.setImageDrawable(null); playIcon.kind = IconView.PLAY; playIcon.invalidate(); bar.progress = 0
                tPos.text = "0:00"; tDur.text = "0:00"
                return
            }
            tTitle.text = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Sin título"
            tSub.text = md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "Reproduciendo"
            val bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            if (bmp != null) art.setImageBitmap(bmp) else art.setImageDrawable(null)
            val ps = ctrl?.playbackState
            val playing = ps?.state == PlaybackState.STATE_PLAYING
            playIcon.kind = if (playing) IconView.PAUSE else IconView.PLAY; playIcon.invalidate()
            val dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION)
            if (ps != null && dur > 0) {
                var pos = ps.position
                if (playing) pos += ((SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * ps.playbackSpeed).toLong()
                bar.progress = (1000L * pos / dur).coerceIn(0L, 1000L).toInt()
                tPos.text = fmt(pos.coerceIn(0L, dur)); tDur.text = fmt(dur)
            } else { bar.progress = 0; tPos.text = "0:00"; tDur.text = "0:00" }
        } catch (e: SecurityException) {
            ctrl = null; mediaAccess = false; tTitle.text = "Activar música en pantalla"; tSub.text = "Toca aquí y permite el acceso"
        } catch (e: Exception) { }
    }

    private fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)

    // ---------- accesos de abajo ----------
    private fun slots(): MutableList<String> {
        val s = prefs.getString("slots6", null)?.split(",")?.toMutableList() ?: defaults.toMutableList()
        while (s.size < 6) s.add(defaults[s.size])
        return s.take(6).toMutableList()
    }

    private fun resolve(t: String): AppItem? = when {
        t == "@radio" -> apps.find { Regex("radio|\\bfm\\b", RegexOption.IGNORE_CASE).containsMatchIn(it.label) }
        t.startsWith("@") -> null
        else -> apps.find { it.pkg == t }
    }

    private fun refreshBottom() {
        bottomRow.removeAllViews()
        val vento = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = glass(20).apply { setStroke(dp(2), accent) }
            addView(IconView(this@MainActivity, IconView.MIC, accent), lp(dp(40), dp(40)))
            addView(tv("Vento", 14f).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) })
            setOnClickListener { openAssistant() }
        }
        bottomRow.addView(vento, lp(0, -1, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        val sl = slots()
        for (i in 0 until 6) {
            val t = sl[i]; val a = resolve(t)
            val v = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = glass(20)
                val special = t.startsWith("@")
                if (a != null && t != "@apps") addView(ImageView(this@MainActivity).apply { setImageDrawable(a.icon) }, lp(dp(46), dp(46)))
                else addView(IconView(this@MainActivity, when (t) { "@bt" -> IconView.BT; "@apps" -> IconView.APPS
                    "@radio" -> IconView.RADIO; else -> IconView.PLUS }, if (special) fg else gray), lp(dp(40), dp(40)))
                addView(tv(if (a != null && !special) a.label else names[i], 14f).apply {
                    gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(4), 0, 0)
                })
                setOnClickListener {
                    when {
                        t == "@bt" -> try { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } catch (e: Exception) { }
                        t == "@apps" -> show(false)
                        a != null -> launch(a.pkg)
                        else -> chooseApp(i)
                    }
                }
                setOnLongClickListener { chooseApp(i); true }
            }
            bottomRow.addView(v, lp(0, -1, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
    }

    private fun chooseApp(i: Int) {
        val labels = apps.map { it.label }.toTypedArray()
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Elegir app para este botón")
            .setItems(labels) { _, w -> val l = slots(); l[i] = apps[w].pkg; prefs.edit().putString("slots6", l.joinToString(",")).apply(); refreshBottom() }
            .setNeutralButton("Restaurar") { _, _ -> val l = slots(); l[i] = defaults[i]; prefs.edit().putString("slots6", l.joinToString(",")).apply(); refreshBottom() }
            .setNegativeButton("Cancelar", null).show()
    }

    // ---------- todas las apps ----------
    private fun tile(a: AppItem): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = glass(20)
        addView(ImageView(this@MainActivity).apply { setImageDrawable(a.icon) }, lp(dp(52), dp(52)))
        addView(tv(a.label, 12f).apply { gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(dp(4), dp(4), dp(4), 0) })
        setOnClickListener { launch(a.pkg) }
    }

    private fun grid(items: List<AppItem>, cols: Int, rowH: Int): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        items.chunked(cols).forEach { chunk ->
            val r = LinearLayout(this)
            for (i in 0 until cols) r.addView(if (i < chunk.size) tile(chunk[i]) else View(this), lp(0, -1, 1f).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) })
            box.addView(r, lp(-1, rowH))
        }
        return box
    }

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.loadIcon(pm), it.activityInfo.packageName) }
            .sortedBy { it.label.lowercase() }
    }
}
